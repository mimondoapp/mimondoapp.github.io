
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  Anchor, 
  Map as MapIcon, 
  Hourglass, 
  Sparkles, 
  Compass, 
  Settings, 
  Globe,
  Bell
} from 'lucide-react';
import { Mundo, EstadoMundo, EntradaAtlas, EventoCronos, AstroNodo, MensajeBitacora, Idioma } from './types';
import Bitacora from './screens/Bitacora';
import Atlas from './screens/Atlas';
import Cronos from './screens/Cronos';
import Astros from './screens/Astros';
import Explorar from './screens/Explorar';
import Mundos from './screens/Mundos';
import SettingsScreen from './screens/Settings';
import OnboardingGuide from './components/OnboardingGuide';
import { processLoreDeeply } from './services/geminiService';
import { translations } from './services/translations';

const INITIAL_MUNDO: Mundo = {
  id: 'mundo-001',
  nombre: 'MiMondo',
  genero: 'Atlas Inteligente',
  sintaxis: 'Creatividad a otro nivel',
  color: '#7dd3fc', 
};

const INITIAL_STATE: EstadoMundo = {
  bitacora: [],
  atlas: [],
  cronos: [],
  astros: []
};

const CATEGORY_COLORS = {
  Personaje: '#3b82f6',
  Lugar: '#10b981',
  Objeto: '#f59e0b',
  Evento: '#f43f5e',
  Concepto: '#64748b',
};

// Utilidad de normalización para deduplicación
const normalizeName = (name: string): string => {
  return name
    .toLowerCase()
    .trim()
    .replace(/^(el|la|los|las|un|una|unos|unas|the|a|an)\s+/i, '') // Quitar artículos al inicio
    .replace(/[^\w\sáéíóúñ]/gi, ''); // Quitar caracteres especiales
};

const Navigation = ({ mundoActivo, t }: { mundoActivo: Mundo, t: any }) => {
  const location = useLocation();
  const navItems = [
    { path: '/', icon: <Anchor size={22} />, label: t.NAV.BITACORA },
    { path: '/atlas', icon: <MapIcon size={22} />, label: t.NAV.ATLAS },
    { path: '/cronos', icon: <Hourglass size={22} />, label: t.NAV.CRONOS },
    { path: '/astros', icon: <Sparkles size={22} />, label: t.NAV.ASTROS },
    { path: '/explorar', icon: <Compass size={22} />, label: t.NAV.EXPLORAR },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 px-4 pt-3 pb-[calc(1rem+var(--safe-area-inset-bottom))] flex justify-around items-center z-50 md:top-0 md:bottom-auto md:left-0 md:w-64 md:h-screen md:flex-col md:justify-start md:pt-28 md:border-t-0 md:border-r transition-all duration-300">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <Link
            key={item.path}
            to={item.path}
            className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all active-scale md:flex-row md:w-full md:px-6 md:py-4 md:gap-4 ${
              isActive 
                ? 'bg-slate-100 dark:bg-slate-800' 
                : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
            }`}
          >
            <span style={{ color: isActive ? mundoActivo.color : 'inherit' }} className="transition-colors duration-300">
              {item.icon}
            </span>
            <span 
              className={`text-[10px] font-bold uppercase tracking-widest md:text-xs md:font-black transition-all duration-300 ${isActive ? 'opacity-100' : 'opacity-60'}`}
              style={{ color: isActive ? mundoActivo.color : 'inherit' }}
            >
              {item.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
};

const Toast = ({ message, visible, onClose, mundoColor }: { message: string, visible: boolean, onClose: () => void, mundoColor: string }) => {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);
  if (!visible) return null;
  return (
    <div className="fixed top-20 right-4 left-4 md:left-auto md:right-8 md:w-80 bg-slate-900/90 backdrop-blur-xl text-white p-5 rounded-3xl shadow-2xl z-[150] flex items-center gap-4 animate-in fade-in slide-in-from-top-6 duration-500 border border-white/10">
      <div className="p-2 rounded-xl" style={{ backgroundColor: mundoColor }}>
        <Bell size={18} className="text-slate-900" />
      </div>
      <p className="text-sm font-black uppercase tracking-tight leading-tight">{message}</p>
    </div>
  );
};

const Header = ({ mundoActivo, onOpenMundos, t }: { mundoActivo: Mundo, onOpenMundos: () => void, t: any }) => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-white/60 dark:bg-slate-950/60 backdrop-blur-2xl border-b border-slate-100 dark:border-slate-800/50 h-20 flex items-center justify-between px-6 z-40 md:left-64 transition-all duration-300">
      <button onClick={onOpenMundos} className="flex items-center gap-4 group transition-all active-scale">
        <div className="p-2.5 rounded-2xl bg-white dark:bg-slate-900 shadow-sm border border-slate-100 dark:border-slate-800 transition-all group-hover:shadow-md" style={{ color: mundoActivo.color }}>
          <Globe size={24} />
        </div>
        <div className="flex flex-col items-start text-left">
          <h1 className="text-sm font-black tracking-tighter text-slate-900 dark:text-white leading-none mb-1 group-hover:text-opacity-70 transition-colors uppercase" style={{ color: mundoActivo.color }}>{mundoActivo.nombre}</h1>
          <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em]">{mundoActivo.genero}</span>
        </div>
      </button>
      <Link to="/settings" className="p-3 rounded-2xl bg-white dark:bg-slate-900 shadow-sm border border-slate-100 dark:border-slate-800 text-slate-400 hover:shadow-md active-scale transition-all">
        <Settings size={22} />
      </Link>
    </header>
  );
};

const App = () => {
  const [mundos, setMundos] = useState<Mundo[]>(() => {
    const saved = localStorage.getItem('mimondo_worlds_list_v2');
    return saved ? JSON.parse(saved) : [INITIAL_MUNDO];
  });

  const [mundoActivoId, setMundoActivoId] = useState(() => {
    return localStorage.getItem('mimondo_active_world_id') || INITIAL_MUNDO.id;
  });

  const [allWorldsData, setAllWorldsData] = useState<Record<string, EstadoMundo>>(() => {
    const saved = localStorage.getItem('mimondo_multiworld_data');
    return saved ? JSON.parse(saved) : { [INITIAL_MUNDO.id]: INITIAL_STATE };
  });

  const [idioma, setIdioma] = useState<Idioma>(() => (localStorage.getItem('mimondo_ui_lang') as Idioma) || 'es');
  
  const t = useMemo(() => translations[idioma], [idioma]);

  const [showMundos, setShowMundos] = useState(false);
  const [notification, setNotification] = useState("");
  const [showOnboarding, setShowOnboarding] = useState(false);

  const mundoActivo = useMemo(() => {
    return mundos.find(m => m.id === mundoActivoId) || mundos[0] || INITIAL_MUNDO;
  }, [mundos, mundoActivoId]);

  const estadoMundo = useMemo(() => {
    return allWorldsData[mundoActivoId] || INITIAL_STATE;
  }, [allWorldsData, mundoActivoId]);

  useEffect(() => {
    document.documentElement.style.setProperty('--color-mundo-activo', mundoActivo.color);
  }, [mundoActivo.color]);

  useEffect(() => {
    localStorage.setItem('mimondo_worlds_list_v2', JSON.stringify(mundos));
    localStorage.setItem('mimondo_active_world_id', mundoActivoId);
    localStorage.setItem('mimondo_multiworld_data', JSON.stringify(allWorldsData));
    localStorage.setItem('mimondo_ui_lang', idioma);
  }, [mundos, mundoActivoId, allWorldsData, idioma]);

  useEffect(() => {
    const isDone = localStorage.getItem('mimondo_onboarding_done');
    if (!isDone) setShowOnboarding(true);
  }, []);

  const notify = (msg: string) => setNotification(msg);

  const setLocalState = useCallback((updater: (prev: EstadoMundo) => EstadoMundo) => {
    setAllWorldsData(prev => {
      const current = prev[mundoActivoId] || INITIAL_STATE;
      return {
        ...prev,
        [mundoActivoId]: updater(current)
      };
    });
  }, [mundoActivoId]);

  const syncLog = useCallback((text: string) => {
    const newMessage: MensajeBitacora = {
      id: Date.now(),
      worldId: mundoActivoId,
      texto: text,
      timestamp: new Date().toISOString()
    };
    setLocalState(prev => ({
      ...prev,
      bitacora: [newMessage, ...prev.bitacora]
    }));
  }, [setLocalState, mundoActivoId]);

  const updateAtlasItem = useCallback((updatedItem: EntradaAtlas) => {
    setLocalState(prev => {
      if (updatedItem.worldId !== mundoActivoId) return prev;
      const newAtlas = prev.atlas.map(a => a.id === updatedItem.id ? updatedItem : a);
      const newAstros = prev.astros.map(node => {
        if (node.id === updatedItem.id) {
          return {
            ...node,
            nombre: updatedItem.nombre,
            categoria: updatedItem.categoria,
            color: CATEGORY_COLORS[updatedItem.categoria as keyof typeof CATEGORY_COLORS] || '#64748b'
          };
        }
        return node;
      });
      return { ...prev, atlas: newAtlas, astros: newAstros };
    });
    notify(`Sincronizado: ${updatedItem.nombre}`);
  }, [setLocalState, notify, mundoActivoId]);

  const deleteAtlasItem = useCallback((id: string) => {
    setLocalState(prev => {
      const itemToDelete = prev.atlas.find(a => a.id === id);
      if (!itemToDelete) return prev;

      const newAtlas = prev.atlas.filter(a => a.id !== id);
      const newAstros = prev.astros
        .filter(n => n.id !== id)
        .map(n => ({
          ...n,
          conexiones: n.conexiones.filter(connId => connId !== id)
        }));
      const newCronos = prev.cronos.filter(c => c.idEntidadAtlas !== id);

      setTimeout(() => syncLog(`SISTEMA: La entidad "${itemToDelete.nombre}" ha sido borrada.`), 100);
      return { ...prev, atlas: newAtlas, astros: newAstros, cronos: newCronos };
    });
    notify(t.COMMON.DELETE);
  }, [setLocalState, syncLog, notify, t]);

  const addAtlasItem = useCallback((item: EntradaAtlas) => {
    setLocalState(prev => {
      const normalizedNew = normalizeName(item.nombre);
      const existingIdx = prev.atlas.findIndex(a => normalizeName(a.nombre) === normalizedNew);

      if (existingIdx >= 0) {
        // MERGE: Si existe, actualizamos contenido y lo notificamos
        const newAtlas = [...prev.atlas];
        newAtlas[existingIdx] = { 
          ...newAtlas[existingIdx], 
          contenido: item.contenido.length > newAtlas[existingIdx].contenido.length ? item.contenido : newAtlas[existingIdx].contenido 
        };
        return { ...prev, atlas: newAtlas };
      }

      const entryWithWorldId = { ...item, worldId: mundoActivoId };
      const newAtlas = [...prev.atlas, entryWithWorldId];
      const newAstros = [...prev.astros];
      
      if (!newAstros.some(n => n.id === item.id)) {
        newAstros.push({
          id: item.id,
          worldId: mundoActivoId,
          nombre: item.nombre,
          categoria: item.categoria,
          x: Math.random() * 800 + 200,
          y: Math.random() * 800 + 200,
          color: CATEGORY_COLORS[item.categoria as keyof typeof CATEGORY_COLORS] || '#64748b',
          conexiones: []
        });
      }
      setTimeout(() => syncLog(`DESCUBRIMIENTO: [[${item.nombre}]] ha sido integrado.`), 100);
      return { ...prev, atlas: newAtlas, astros: newAstros };
    });
  }, [setLocalState, syncLog, mundoActivoId]);

  const handleMergeDuplicates = useCallback(() => {
    setLocalState(prev => {
      const uniqueItems: Record<string, EntradaAtlas> = {};
      const newAstros = [...prev.astros];
      const newCronos = [...prev.cronos];

      prev.atlas.forEach(item => {
        const key = normalizeName(item.nombre);
        if (uniqueItems[key]) {
          // Fusionar contenido si es más largo
          if (item.contenido.length > uniqueItems[key].contenido.length) {
            uniqueItems[key].contenido = item.contenido;
          }
          // Fusionar campos de inicio/fin si el original no los tiene
          if (!uniqueItems[key].descripcionInicio && item.descripcionInicio) uniqueItems[key].descripcionInicio = item.descripcionInicio;
          if (!uniqueItems[key].descripcionFinal && item.descripcionFinal) uniqueItems[key].descripcionFinal = item.descripcionFinal;
          
          // Re-mapear Cronos y Astros que usen el ID antiguo al ID que queda
          const oldId = item.id;
          const keepId = uniqueItems[key].id;
          
          newCronos.forEach(c => { if (c.idEntidadAtlas === oldId) c.idEntidadAtlas = keepId; });
          // Eliminar el nodo sobrante de astros
          const nodeIdx = newAstros.findIndex(n => n.id === oldId);
          if (nodeIdx >= 0) newAstros.splice(nodeIdx, 1);
        } else {
          uniqueItems[key] = { ...item };
        }
      });

      return {
        ...prev,
        atlas: Object.values(uniqueItems),
        astros: newAstros,
        cronos: newCronos
      };
    });
    notify(t.ATLAS.MERGE_SUCCESS);
  }, [setLocalState, notify, t]);

  const processTextAndSync = async (text: string, isFullCleanup: boolean = false) => {
    const worldContext = `
      Mundo Activo: ${mundoActivo.nombre} (ID: ${mundoActivo.id}). 
      Atlas Local: ${estadoMundo.atlas.map(a => `${a.nombre} (${a.categoria}): ${a.descripcion}`).join('; ')}.
    `;
    
    try {
      const aiLang = idioma === 'es' ? 'Español' : 'English';
      const analysis = await processLoreDeeply(text, worldContext, aiLang);
      
      setLocalState(prev => {
        let newAtlas = [...prev.atlas];
        let newCronos = [...prev.cronos];

        // 1. Integración Atlas con Deduplicación Normalizada
        analysis.atlas?.forEach((entry: any) => {
          const normName = normalizeName(entry.nombre);
          const idx = newAtlas.findIndex(a => normalizeName(a.nombre) === normName);
          
          if (idx >= 0) {
            // PATCH: Fusión inteligente
            const existing = newAtlas[idx];
            newAtlas[idx] = {
              ...existing,
              descripcion: entry.descripcion || existing.descripcion,
              contenido: entry.contenido.length > existing.contenido.length ? entry.contenido : existing.contenido,
              descripcionInicio: entry.descripcionInicio || existing.descripcionInicio,
              descripcionFinal: entry.descripcionFinal || existing.descripcionFinal,
              categoria: entry.categoria as any || existing.categoria
            };
          } else {
            // POST: Nueva entidad
            const newId = (Date.now() + Math.random()).toString();
            newAtlas.push({
              id: newId,
              worldId: mundoActivoId,
              nombre: entry.nombre,
              categoria: entry.categoria as any,
              descripcion: entry.descripcion,
              contenido: entry.contenido,
              descripcionInicio: entry.descripcionInicio,
              descripcionFinal: entry.descripcionFinal,
              etiquetas: [entry.categoria],
              imagenUrl: `https://picsum.photos/seed/${entry.nombre}/400/300`
            });
          }
        });

        // 2. Integración Cronos
        analysis.cronos?.forEach((ev: any) => {
          const isDuplicate = newCronos.some(c => 
            normalizeName(c.titulo) === normalizeName(ev.titulo) && 
            normalizeName(c.fecha) === normalizeName(ev.fecha)
          );

          if (!isDuplicate) {
            let atlasEntry = newAtlas.find(a => normalizeName(a.nombre) === normalizeName(ev.titulo));
            
            if (!atlasEntry) {
              const rootId = (Date.now() + Math.random()).toString();
              const newRoot: EntradaAtlas = {
                id: rootId,
                worldId: mundoActivoId,
                nombre: ev.titulo,
                categoria: 'Evento',
                descripcion: `${ev.fecha}: ${ev.descripcion}`,
                contenido: ev.descripcion,
                etiquetas: ['Evento', 'Cronos']
              };
              newAtlas.push(newRoot);
              atlasEntry = newRoot;
            }

            newCronos.push({
              id: (Date.now() + Math.random()).toString(),
              worldId: mundoActivoId,
              titulo: ev.titulo,
              fecha: ev.fecha,
              descripcionCorta: ev.descripcion,
              idEntidadAtlas: atlasEntry.id
            });
          }
        });

        // 3. Sincronización Astros
        const newAstros = [...prev.astros];
        newAtlas.forEach(entry => {
          const existsIdx = newAstros.findIndex(n => n.id === entry.id || normalizeName(n.nombre) === normalizeName(entry.nombre));
          if (existsIdx === -1) {
            newAstros.push({
              id: entry.id,
              worldId: mundoActivoId,
              nombre: entry.nombre,
              categoria: entry.categoria,
              x: Math.random() * 1200 + 400,
              y: Math.random() * 1200 + 400,
              color: CATEGORY_COLORS[entry.categoria as keyof typeof CATEGORY_COLORS] || '#64748b',
              conexiones: []
            });
          } else {
            newAstros[existsIdx].nombre = entry.nombre;
            newAstros[existsIdx].categoria = entry.categoria;
            newAstros[existsIdx].color = CATEGORY_COLORS[entry.categoria as keyof typeof CATEGORY_COLORS] || '#64748b';
            newAstros[existsIdx].worldId = mundoActivoId;
          }
        });

        // 4. Astro Protocol
        analysis.astros?.forEach((conn: any) => {
          const nodeA = newAstros.find(n => normalizeName(n.nombre) === normalizeName(conn.entidadA));
          const nodeB = newAstros.find(n => normalizeName(n.nombre) === normalizeName(conn.entidadB));
          if (nodeA && nodeB && nodeA.id !== nodeB.id && !nodeA.conexiones.includes(nodeB.id)) {
            nodeA.conexiones.push(nodeB.id);
          }
        });

        return {
          ...prev,
          atlas: newAtlas,
          cronos: newCronos.slice(-100),
          astros: newAstros
        };
      });
      notify("Oráculo sincronizado.");
    } catch (e: any) {
      notify(e.message || "Error del Oráculo.");
    }
  };

  return (
    <HashRouter>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-all duration-500 ease-in-out">
        <Navigation mundoActivo={mundoActivo} t={t} />
        <Header mundoActivo={mundoActivo} onOpenMundos={() => setShowMundos(true)} t={t} />
        <main className="pt-24 pb-32 md:pb-12 md:pl-72 min-h-screen transition-all duration-300">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <Routes>
              <Route path="/" element={<Bitacora mundoActivo={mundoActivo} messages={estadoMundo.bitacora} setMessages={(msgs) => setLocalState(p => ({...p, bitacora: msgs}))} onAnalyze={processTextAndSync} t={t} />} />
              <Route path="/atlas" element={
                <Atlas 
                  items={estadoMundo.atlas} 
                  onUpdate={updateAtlasItem}
                  onDelete={deleteAtlasItem}
                  onAdd={addAtlasItem}
                  onAnalyze={processTextAndSync} 
                  onAddToBitacora={syncLog} 
                  onMerge={handleMergeDuplicates}
                  mundoActivo={mundoActivo}
                  worldContext={`${mundoActivo.nombre}: ${mundoActivo.sintaxis}`} 
                  aiLanguage={idioma === 'es' ? 'Español' : 'English'} 
                  t={t}
                />
              } />
              <Route path="/cronos" element={<Cronos timeline={estadoMundo.cronos} atlasItems={estadoMundo.atlas} mundoColor={mundoActivo.color} t={t} />} />
              <Route path="/astros" element={<Astros nodes={estadoMundo.astros} mundoColor={mundoActivo.color} />} />
              <Route path="/explorar" element={<Explorar mundoActivo={mundoActivo} atlasItems={estadoMundo.atlas} aiLanguage={idioma === 'es' ? 'Español' : 'English'} onSaveIdea={(text) => { syncLog(text); processTextAndSync(text); }} t={t} />} />
              <Route path="/settings" element={<SettingsScreen onNotify={notify} onShowOnboarding={() => setShowOnboarding(true)} idioma={idioma} setIdioma={setIdioma} t={t} />} />
            </Routes>
          </div>
        </main>
        <Toast message={notification} visible={!!notification} onClose={() => setNotification("")} mundoColor={mundoActivo.color} />
        {showOnboarding && <OnboardingGuide onComplete={() => setShowOnboarding(false)} t={t} />}
        {showMundos && (
          <Mundos 
            mundos={mundos}
            allWorldsData={allWorldsData}
            onClose={() => setShowMundos(false)} 
            onSelect={(mId) => { setMundoActivoId(mId); setShowMundos(false); }} 
            onCreate={(nuevo) => { setMundos([...mundos, nuevo]); setAllWorldsData(prev => ({ ...prev, [nuevo.id]: INITIAL_STATE })); }}
            onDelete={(id) => { setMundos(mundos.filter(m => m.id !== id)); setAllWorldsData(prev => { const d = {...prev}; delete d[id]; return d; }); }}
            onUpdate={(u) => setMundos(mundos.map(m => m.id === u.id ? u : m))}
            currentMundoId={mundoActivoId} 
            t={t}
          />
        )}
      </div>
    </HashRouter>
  );
};

export default App;
