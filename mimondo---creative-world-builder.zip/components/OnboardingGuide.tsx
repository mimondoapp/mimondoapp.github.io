
import React, { useState } from 'react';
import { Sparkles, Zap, BookOpen, Key, ChevronRight, ExternalLink } from 'lucide-react';

interface OnboardingProps {
  onComplete: () => void;
  t: any;
}

const OnboardingGuide = ({ onComplete, t }: OnboardingProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [keys, setKeys] = useState({
    k1: localStorage.getItem('mimondo_key_1') || '',
    k2: localStorage.getItem('mimondo_key_2') || '',
    k3: localStorage.getItem('mimondo_key_3') || '',
  });

  const STEPS = [
    {
      title: t.es ? "Bienvenido a MiMondo" : "Welcome to MiMondo",
      description: t.es ? "El primer atlas inteligente que respira con tu imaginación." : "The first intelligent atlas that breathes with your imagination.",
      icon: <Sparkles className="text-blue-500" size={48} />,
      color: "bg-blue-50 dark:bg-blue-900/20"
    },
    {
      title: t.SETTINGS.ENERGY,
      description: t.SETTINGS.KEYS_DESC,
      icon: <Key className="text-amber-500" size={48} />,
      color: "bg-amber-50 dark:bg-amber-900/20",
      isAPI: true
    },
    {
      title: t.NAV.BITACORA,
      description: t.BITACORA.EMPTY_SUB,
      icon: <BookOpen className="text-emerald-500" size={48} />,
      color: "bg-emerald-50 dark:bg-emerald-900/20"
    }
  ];

  const handleSaveKeys = () => {
    localStorage.setItem('mimondo_key_1', keys.k1);
    localStorage.setItem('mimondo_key_2', keys.k2);
    localStorage.setItem('mimondo_key_3', keys.k3);
  };

  const next = () => {
    if (currentStep === 1) {
      if (!keys.k1 && !keys.k2 && !keys.k3) {
        alert("API Key required.");
        return;
      }
      handleSaveKeys();
    }
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      localStorage.setItem('mimondo_onboarding_done', 'true');
      onComplete();
    }
  };

  const step = STEPS[currentStep];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-2xl animate-in fade-in duration-500" />
      <div className="relative bg-white dark:bg-slate-900 w-full max-w-lg rounded-[3.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-white/10">
        <div className={`h-40 flex items-center justify-center ${step.color} transition-colors duration-500`}>{step.icon}</div>
        <div className="p-10 space-y-8">
          <div className="text-center space-y-3">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tighter">{step.title}</h2>
            <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium text-sm">{step.description}</p>
          </div>
          {step.isAPI && (
            <div className="space-y-4">
              <div className="flex justify-center">
                <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] bg-blue-50 dark:bg-blue-900/20 px-4 py-2 rounded-full hover:scale-105 transition-all">
                  API Studio <ExternalLink size={12} />
                </a>
              </div>
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <input key={i} type="password" value={(keys as any)[`k${i}`]} onChange={(e) => setKeys({...keys, [`k${i}`]: e.target.value})} placeholder={`${t.SETTINGS.ENERGY} ${i}...`} className="w-full pl-6 pr-4 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl outline-none text-xs font-mono" />
                ))}
              </div>
            </div>
          )}
          <div className="flex gap-4">
            {currentStep > 0 && <button onClick={() => setCurrentStep(currentStep - 1)} className="flex-1 py-5 rounded-[2rem] border border-slate-200 dark:border-slate-800 text-slate-500 font-black text-[10px] uppercase tracking-widest">{t.COMMON.BACK}</button>}
            <button onClick={next} className="flex-[2] py-5 rounded-[2rem] bg-slate-900 dark:bg-blue-600 text-white font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
              {currentStep === STEPS.length - 1 ? t.COMMON.START : t.COMMON.NEXT} <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingGuide;
