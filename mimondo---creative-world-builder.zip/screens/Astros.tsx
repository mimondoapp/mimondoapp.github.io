
import React, { useEffect, useRef, useState } from 'react';
import { Search, ZoomIn, ZoomOut, Maximize, Activity, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AstroNodo } from '../types';

interface AstrosProps {
  nodes: AstroNodo[];
  mundoColor: string;
}

const CATEGORY_COLORS = {
  Personaje: '#3b82f6', // Blue
  Lugar: '#10b981',    // Emerald
  Objeto: '#f59e0b',    // Amber
  Evento: '#f43f5e',    // Rose
  Concepto: '#64748b',  // Slate
};

const Astros = ({ nodes, mundoColor }: AstrosProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  
  const [zoom, setZoom] = useState(1);
  const [search, setSearch] = useState('');
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [hasCentered, setHasCentered] = useState(false);

  useEffect(() => {
    const observer = new MutationObserver(() => {
      setIsDarkMode(document.documentElement.classList.contains('dark'));
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (nodes.length > 0 && canvasRef.current && !hasCentered) {
      const sumX = nodes.reduce((acc, n) => acc + n.x, 0);
      const sumY = nodes.reduce((acc, n) => acc + n.y, 0);
      const avgX = sumX / nodes.length;
      const avgY = sumY / nodes.length;

      setOffset({
        x: -(avgX - canvasRef.current.width / 2),
        y: -(avgY - canvasRef.current.height / 2)
      });
      setHasCentered(true);
    }
  }, [nodes, hasCentered]);

  const drawStar4 = (ctx: CanvasRenderingContext2D, cx: number, cy: number, outerRadius: number, innerRadius: number) => {
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / 4;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < 4; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (containerRef.current) {
      canvas.width = containerRef.current.clientWidth;
      canvas.height = containerRef.current.clientHeight;
    }

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      
      // Transformación global de cámara
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(zoom, zoom);
      ctx.translate(-canvas.width / 2 + offset.x, -canvas.height / 2 + offset.y);

      // 1. Dibujar Enlaces (Reparado) - Dibujamos líneas primero para que queden bajo los nodos
      nodes.forEach(node => {
        const isSelfSelected = selectedNodeId === node.id;
        
        if (node.conexiones && Array.isArray(node.conexiones)) {
          node.conexiones.forEach(targetId => {
            const target = nodes.find(n => n.id === targetId);
            if (!target) return;

            const isTargetSelected = selectedNodeId === targetId;
            const isHighlight = isSelfSelected || isTargetSelected;

            ctx.beginPath();
            ctx.setLineDash(isHighlight ? [] : [8, 4]);
            ctx.lineWidth = isHighlight ? 4 : 2;
            
            if (isHighlight) {
              ctx.strokeStyle = mundoColor;
              ctx.shadowBlur = 15;
              ctx.shadowColor = mundoColor;
              ctx.globalAlpha = 1.0;
            } else {
              // Color base según el mundo con opacidad mejorada
              ctx.strokeStyle = isDarkMode ? `${mundoColor}66` : `${mundoColor}99`;
              ctx.shadowBlur = 0;
              ctx.globalAlpha = 0.6;
            }

            ctx.moveTo(node.x, node.y);
            ctx.lineTo(target.x, target.y);
            ctx.stroke();
            ctx.globalAlpha = 1.0;
            ctx.shadowBlur = 0;
          });
        }
      });
      
      ctx.setLineDash([]);

      // 2. Dibujar Estrellas (Nodos)
      nodes.forEach(node => {
        const isMatch = search && node.nombre.toLowerCase().includes(search.toLowerCase());
        const isSelected = selectedNodeId === node.id;
        const starSize = isMatch || isSelected ? 32 : 22;
        
        const nodeColor = CATEGORY_COLORS[node.categoria as keyof typeof CATEGORY_COLORS] || node.color || '#fff';

        ctx.save();
        ctx.shadowBlur = isMatch || isSelected ? 40 : 15;
        ctx.shadowColor = nodeColor;
        ctx.fillStyle = nodeColor;
        
        drawStar4(ctx, node.x, node.y, starSize, starSize / 3);
        ctx.fill();

        if (isSelected) {
          ctx.strokeStyle = isDarkMode ? '#fff' : '#000';
          ctx.lineWidth = 3;
          ctx.stroke();
        }

        ctx.shadowBlur = 0;
        ctx.fillStyle = isDarkMode ? '#f8fafc' : '#1e293b';
        ctx.font = isSelected ? '900 14px Inter' : '700 12px Inter';
        ctx.textAlign = 'center';
        ctx.fillText(node.nombre.toUpperCase(), node.x, node.y + starSize + 22);
        ctx.restore();
      });

      ctx.restore();
    };

    const animFrame = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animFrame);
  }, [zoom, search, nodes, offset, isDarkMode, selectedNodeId, mundoColor]);

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (isDragging) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const worldX = (mouseX - canvas.width / 2) / zoom + canvas.width / 2 - offset.x;
    const worldY = (mouseY - canvas.height / 2) / zoom + canvas.height / 2 - offset.y;

    const clickedNode = nodes.find(node => {
      const dist = Math.sqrt((worldX - node.x) ** 2 + (worldY - node.y) ** 2);
      return dist < 40 / zoom;
    });

    setSelectedNodeId(clickedNode ? clickedNode.id : null);
  };

  const selectedNode = nodes.find(n => n.id === selectedNodeId);

  return (
    <div 
      ref={containerRef}
      className="relative h-[calc(100vh-14rem)] bg-white dark:bg-slate-950 rounded-premium border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl"
    >
      {nodes.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full space-y-4">
          <Activity size={48} className="text-slate-200 animate-pulse" />
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Esperando datos del Atlas...</p>
        </div>
      ) : (
        <canvas 
          ref={canvasRef} 
          onClick={handleCanvasClick}
          onMouseDown={(e) => { 
            setIsDragging(false);
            setLastMousePos({ x: e.clientX, y: e.clientY }); 
          }}
          onMouseMove={(e) => {
            const dx = Math.abs(e.clientX - lastMousePos.x);
            const dy = Math.abs(e.clientY - lastMousePos.y);
            if (dx > 5 || dy > 5) {
              if (e.buttons === 1) {
                setIsDragging(true);
                setOffset(prev => ({ x: prev.x + (e.clientX - lastMousePos.x) / zoom, y: prev.y + (e.clientY - lastMousePos.y) / zoom }));
                setLastMousePos({ x: e.clientX, y: e.clientY });
              }
            }
          }}
          onMouseUp={() => setTimeout(() => setIsDragging(false), 50)}
          className={`w-full h-full ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        />
      )}

      {selectedNode && (
        <div 
          className="absolute z-50 animate-in zoom-in-95 duration-200 flex flex-col items-center pointer-events-none"
          style={{
            left: (selectedNode.x + offset.x - canvasRef.current!.width/2) * zoom + canvasRef.current!.width/2,
            top: (selectedNode.y + offset.y - canvasRef.current!.height/2) * zoom + canvasRef.current!.height/2 - 90,
          }}
        >
          <button 
            onClick={() => navigate('/atlas', { state: { openId: selectedNode.id } })}
            className="pointer-events-auto flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest shadow-2xl hover:scale-105 active-scale transition-all"
            style={{ backgroundColor: mundoColor, color: '#1e293b' }}
          >
            <ExternalLink size={14} /> Ver Ficha
          </button>
          <div className="w-1 h-8 mt-1 shadow-lg rounded-full" style={{ backgroundColor: mundoColor }} />
        </div>
      )}

      <div className="absolute top-6 left-6 flex flex-col gap-3">
        <div className="relative pointer-events-auto">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            value={search} 
            onChange={(e) => setSearch(e.target.value)} 
            placeholder="Encontrar astro..." 
            className="pl-12 pr-4 py-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur shadow-2xl border border-slate-200 dark:border-slate-800 rounded-full text-[11px] font-bold outline-none w-48 transition-all focus:w-64" 
          />
        </div>
      </div>

      <div className="absolute bottom-6 right-6 flex flex-col gap-2 bg-white/90 dark:bg-slate-900/90 backdrop-blur p-2 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl">
        <button onClick={() => setZoom(z => Math.min(3, z + 0.2))} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl text-slate-600 transition-colors active-scale"><ZoomIn size={20} /></button>
        <button onClick={() => setZoom(z => Math.max(0.2, z - 0.2))} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl text-slate-600 transition-colors active-scale"><ZoomOut size={20} /></button>
        <div className="h-px bg-slate-200 dark:bg-slate-800 mx-2 my-1" />
        <button onClick={() => { setZoom(1); setHasCentered(false); setSelectedNodeId(null); }} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl text-slate-600 transition-colors active-scale"><Maximize size={20} /></button>
      </div>
    </div>
  );
};

export default Astros;
