
import React, { useState, useEffect } from 'react';
import { Search, X, FileText, Plus, User, MapPin, Box, Zap, Sparkles, Save, RotateCcw, MoreVertical, Trash2, Printer, CheckCircle, Layers, ChevronDown } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { EntradaAtlas, Mundo } from '../types';
import { expandAtlasItem } from '../services/geminiService';

interface AtlasProps {
  items: EntradaAtlas[];
  onUpdate: (item: EntradaAtlas) => void;
  onDelete: (id: string) => void;
  onAdd: (item: EntradaAtlas) => void;
  onAnalyze: (text: string) => Promise<void>;
  onAddToBitacora: (text: string) => void;
  onMerge: () => void;
  mundoActivo: Mundo;
  worldContext: string;
  aiLanguage: string;
  t: any;
}

const CategoryBadge = ({ category }: { category: EntradaAtlas['categoria'] }) => {
  const styles = {
    Personaje: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400',
    Lugar: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400',
    Objeto: 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400',
    Evento: 'bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400',
    Concepto: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
  };
  const icons = {
    Personaje: <User size={10} />,
    Lugar: <MapPin size={10} />,
    Objeto: <Box size={10} />,
    Evento: <Zap size={10} />,
    Concepto: <FileText size={10} />,
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.1em] shadow-sm ${styles[category]}`}>
      {icons[category]} {category}
    </span>
  );
};

const Atlas = ({ items, onUpdate, onDelete, onAdd, onAnalyze, onAddToBitacora, onMerge, mundoActivo, worldContext, aiLanguage, t }: AtlasProps) => {
  const [search, setSearch] = useState('');
  const [selectedItem, setSelectedItem] = useState<EntradaAtlas | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [editForm, setEditForm] = useState<EntradaAtlas | null>(null);
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [selection, setSelection] = useState<string[]>([]);
  
  const location = useLocation();

  useEffect(() => {
    if (location.state?.openId) {
      const target = items.find(i => i.id === location.state.openId);
      if (target) {
        setSelectedItem(target);
        window.history.replaceState({}, document.title);
      }
    }
  }, [location.state, items]);

  const filteredItems = items.filter(i => 
    i.nombre.toLowerCase().includes(search.toLowerCase()) || i.categoria.toLowerCase().includes(search.toLowerCase())
  );

  const handleAnalyzeAndSave = async () => {
    if (!editForm) return;
    setIsAnalyzing(true);
    if (items.some(i => i.id === editForm.id)) {
      onUpdate(editForm);
    } else {
      onAdd(editForm);
    }
    await onAnalyze(`${editForm.nombre}: ${editForm.contenido}`);
    setSelectedItem(editForm);
    setIsEditing(false);
    setIsAnalyzing(false);
  };

  const handleExpand = async () => {
    if (!selectedItem) return;
    setIsAnalyzing(true);
    try {
      const expansion = await expandAtlasItem(selectedItem, worldContext, aiLanguage);
      const updated = { ...selectedItem, contenido: selectedItem.contenido + "\n\n" + expansion };
      setEditForm(updated);
      setIsEditing(true);
    } catch (e) { console.error(e); }
    finally { setIsAnalyzing(false); }
  };

  const exportItemsToPDF = (itemsToExport: EntradaAtlas[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const content = itemsToExport.map(item => `
      <div class="entry" style="margin-bottom: 2rem; page-break-inside: avoid;">
        <div style="font-size: 8px; font-weight: 900; color: ${mundoActivo.color}; text-transform: uppercase;">${item.categoria}</div>
        <h2 style="font-family: serif; font-size: 24px; margin: 0 0 10px 0;">${item.nombre}</h2>
        <div style="font-style: italic; color: #666; margin-bottom: 15px;">${item.descripcion}</div>
        <div style="white-space: pre-wrap; line-height: 1.6;">${item.contenido}</div>
      </div>
    `).join('<hr style="opacity: 0.1; margin: 2rem 0;"/>');

    printWindow.document.write(`
      <html>
        <head>
          <title>${t.NAV.ATLAS} - MiMondo</title>
          <style>body { font-family: 'Inter', sans-serif; padding: 40px; color: #111; }</style>
        </head>
        <body>
          <h1 style="text-align: center; text-transform: uppercase; font-size: 10px; font-weight: 900; letter-spacing: 4px; margin-bottom: 40px; border-bottom: 1px solid #eee; padding-bottom: 20px;">${t.NAV.ATLAS} - ${mundoActivo.nombre}</h1>
          ${content}
          <script>setTimeout(() => { window.print(); window.close(); }, 500);</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const toggleSelect = (id: string) => {
    setSelection(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleBulkDelete = () => {
    if (confirm(t.ATLAS.BULK_DELETE || "¿Borrar seleccionados?")) {
      selection.forEach(id => onDelete(id));
      setSelection([]);
    }
  };

  const handleBulkExport = () => {
    const selectedItems = items.filter(i => selection.includes(i.id));
    exportItemsToPDF(selectedItems);
    setSelection([]);
  };

  const renderContent = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(\[\[.*?\]\])/g);
    return parts.map((part, i) => {
      if (part.startsWith('[[') && part.endsWith(']]')) {
        const name = part.slice(2, -2);
        const target = items.find(it => it.nombre.toLowerCase() === name.toLowerCase());
        return target ? (
          <button key={i} onClick={(e) => { e.stopPropagation(); setSelectedItem(target); }} className="font-black hover:underline px-0.5" style={{ color: mundoActivo.color }}>{name}</button>
        ) : <span key={i} className="text-slate-400 font-bold">{name}</span>;
      }
      return part;
    });
  };

  return (
    <div className="space-y-6 md:space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700 max-w-5xl mx-auto pb-32 relative">
      {/* Barra de Selección Masiva (Flotante) */}
      {selection.length > 0 && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-2rem)] max-w-lg bg-slate-900/90 dark:bg-slate-800/90 backdrop-blur-2xl px-6 py-4 rounded-full shadow-2xl border border-white/10 flex items-center justify-between gap-4 animate-in slide-in-from-top-12 duration-500">
           <div className="flex items-center gap-4">
              <button onClick={() => setSelection([])} className="p-2 bg-white/10 rounded-full text-white active-scale">
                <X size={16} />
              </button>
              <span className="text-white text-[11px] font-black uppercase tracking-widest">{selection.length} {t.COMMON.CLEAN ? 'Seleccionados' : 'Selected'}</span>
           </div>
           <div className="flex items-center gap-2">
              <button onClick={handleBulkExport} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all active-scale" title={t.COMMON.EXPORT_PDF}>
                <Printer size={18} />
              </button>
              <button onClick={handleBulkDelete} className="p-3 bg-rose-500/20 hover:bg-rose-500/40 text-rose-400 rounded-2xl transition-all active-scale" title={t.COMMON.DELETE}>
                <Trash2 size={18} />
              </button>
           </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center gap-4 px-1 md:px-0">
        <div className="relative flex-1 group">
          <Search size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 transition-all duration-300" style={{ color: mundoActivo.color }} />
          <input 
            type="text" 
            value={search} 
            onChange={(e) => setSearch(e.target.value)} 
            placeholder={t.COMMON.SEARCH} 
            className="w-full pl-14 pr-8 py-4 md:py-5 bg-white dark:bg-slate-900 rounded-3xl md:rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-lg outline-none text-base font-bold transition-all focus:ring-4" 
            style={{ ringColor: `${mundoActivo.color}33` }}
          />
        </div>
        <button 
          onClick={() => { if(confirm(t.ATLAS.MERGE_DUPLICATES + "?")) onMerge(); }}
          className="flex items-center justify-center gap-3 px-8 py-4 md:py-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-lg active-scale transition-all hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          <Layers size={20} style={{ color: mundoActivo.color }} />
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">{t.ATLAS.MERGE_DUPLICATES}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {filteredItems.map((item) => {
          const isSelected = selection.includes(item.id);
          const isMenuOpen = menuOpenId === item.id;
          
          return (
            <div 
              key={item.id} 
              onContextMenu={(e) => { e.preventDefault(); toggleSelect(item.id); }} // Long press fallback/Desktop
              onClick={() => selection.length > 0 ? toggleSelect(item.id) : setSelectedItem(item)} 
              className={`group relative bg-white dark:bg-slate-900 rounded-[2.5rem] border transition-all duration-500 cursor-pointer ${isSelected ? 'scale-[1.02] shadow-2xl' : 'border-slate-100 dark:border-slate-800 hover:shadow-2xl'} ${isMenuOpen ? 'z-50' : 'z-10'}`}
              style={{ borderColor: isSelected ? mundoActivo.color : undefined }}
            >
              <button 
                onClick={(e) => { 
                  e.stopPropagation(); 
                  if (selection.length > 0) {
                    toggleSelect(item.id);
                  } else {
                    setMenuOpenId(isMenuOpen ? null : item.id);
                  }
                }}
                className={`absolute top-5 right-5 z-[60] p-2.5 rounded-2xl backdrop-blur-xl transition-all ${isSelected || isMenuOpen ? 'shadow-lg bg-white/20' : 'bg-black/20 text-white opacity-0 group-hover:opacity-100'}`}
                style={{ backgroundColor: isSelected || isMenuOpen ? mundoActivo.color : undefined, color: isSelected || isMenuOpen ? '#1e293b' : undefined }}
              >
                {isSelected ? <CheckCircle size={20} /> : <MoreVertical size={20} />}
              </button>

              {isMenuOpen && (
                <div 
                  className="absolute top-16 right-5 z-[100] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-2xl p-2 min-w-[200px] animate-in slide-in-from-top-4 duration-300" 
                  onClick={(e) => e.stopPropagation()}
                >
                  <button 
                    onClick={() => { toggleSelect(item.id); setMenuOpenId(null); }} 
                    className="w-full flex items-center gap-4 px-5 py-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-colors text-left"
                  >
                     <CheckCircle size={16} style={{ color: isSelected ? mundoActivo.color : '#94a3b8' }} /> {isSelected ? t.COMMON.CLEAN : 'Seleccionar Varios'}
                  </button>
                  <button 
                    onClick={() => { exportItemsToPDF([item]); setMenuOpenId(null); }} 
                    className="w-full flex items-center gap-4 px-5 py-4 hover:bg-slate-50 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-colors text-left" 
                    style={{ color: mundoActivo.color }}
                  >
                    <Printer size={16} /> {t.COMMON.EXPORT_PDF}
                  </button>
                  <div className="h-px bg-slate-100 dark:bg-slate-800 my-1 mx-2" />
                  <button 
                    onClick={() => { if(confirm(t.MUNDOS.DELETE_CONFIRM)) onDelete(item.id); setMenuOpenId(null); }} 
                    className="w-full flex items-center gap-4 px-5 py-4 hover:bg-rose-50 text-rose-500 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-colors text-left"
                  >
                    <Trash2 size={16} /> {t.COMMON.DELETE}
                  </button>
                </div>
              )}

              <div className="aspect-[16/10] bg-slate-100 dark:bg-slate-800 relative overflow-hidden rounded-t-[2.5rem]">
                <img src={item.imagenUrl} alt={item.nombre} className="w-full h-full object-cover group-hover:scale-110 duration-1000 opacity-90 transition-transform" />
                <div className="absolute top-4 left-4"><CategoryBadge category={item.categoria} /></div>
                {isSelected && (
                  <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center animate-in fade-in">
                    <CheckCircle size={48} className="text-white drop-shadow-lg" style={{ color: mundoActivo.color }} />
                  </div>
                )}
              </div>
              
              <div className="p-6 md:p-8 space-y-3">
                <h3 className="font-black text-xl text-slate-900 dark:text-white tracking-tighter uppercase truncate leading-none">{item.nombre}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs line-clamp-2 leading-relaxed font-medium uppercase tracking-tight">{item.descripcion}</p>
                {item.categoria === 'Evento' && item.descripcionInicio && (
                   <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border-l-4" style={{ borderColor: mundoActivo.color }}>
                      <p className="text-[10px] font-black uppercase text-slate-400 mb-1">Inicio Registrado</p>
                      <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300 line-clamp-1">{item.descripcionInicio}</p>
                   </div>
                )}
              </div>
            </div>
          );
        })}

        <button 
          onClick={() => {
            const newItem: EntradaAtlas = { 
              id: Date.now().toString(), 
              worldId: mundoActivo.id,
              nombre: t.COMMON.NEW, 
              categoria: 'Concepto', 
              descripcion: '', 
              contenido: '', 
              etiquetas: [] 
            };
            setEditForm(newItem); setIsEditing(true); setSelectedItem(newItem);
          }}
          className="flex flex-col items-center justify-center gap-6 p-10 md:p-12 border-4 border-dashed rounded-[2.5rem] transition-all group active-scale"
          style={{ borderColor: `${mundoActivo.color}33`, color: mundoActivo.color }}
        >
          <Plus size={36} />
          <span className="font-black uppercase text-[11px] tracking-[0.3em]">{t.ATLAS.EMPTY_SUB}</span>
        </button>
      </div>

      {selectedItem && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-2xl" onClick={() => !isEditing && setSelectedItem(null)} />
          <div className="relative bg-white dark:bg-slate-950 w-full max-w-4xl h-full sm:h-auto max-h-full sm:max-h-[90vh] sm:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95">
             <div className="h-48 sm:h-72 relative shrink-0">
               <img src={selectedItem.imagenUrl || `https://picsum.photos/seed/${selectedItem.nombre}/1200/800`} className="w-full h-full object-cover" />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20" />
               <div className="absolute bottom-6 sm:bottom-8 left-6 sm:left-8 right-6 sm:right-8 text-white">
                  {!isEditing ? (
                    <div className="space-y-2 sm:space-y-3">
                      <CategoryBadge category={selectedItem.categoria} />
                      <h2 className="text-2xl sm:text-3xl md:text-5xl font-black uppercase tracking-tighter leading-none">{selectedItem.nombre}</h2>
                    </div>
                  ) : (
                    <div className="space-y-2 text-left">
                      <select value={editForm?.categoria} onChange={(e) => setEditForm({...editForm!, categoria: e.target.value as any})} className="bg-white/10 text-white rounded-full px-4 py-1 text-[10px] font-black outline-none backdrop-blur-md">
                        <option value="Personaje" className="bg-slate-900">Personaje</option>
                        <option value="Lugar" className="bg-slate-900">Lugar</option>
                        <option value="Objeto" className="bg-slate-900">Objeto</option>
                        <option value="Evento" className="bg-slate-900">Evento</option>
                        <option value="Concepto" className="bg-slate-900">Concepto</option>
                      </select>
                      <input value={editForm?.nombre} onChange={(e) => setEditForm({...editForm!, nombre: e.target.value})} className="bg-transparent text-2xl sm:text-3xl font-black outline-none border-b-2 border-white/20 w-full uppercase" />
                    </div>
                  )}
               </div>
               <button onClick={() => setSelectedItem(null)} className="absolute top-6 right-6 p-2.5 bg-black/40 rounded-full text-white backdrop-blur-xl active-scale"><X size={20} /></button>
             </div>

             <div className="p-6 sm:p-12 overflow-y-auto flex-1 space-y-8 custom-scrollbar">
                {!isEditing ? (
                  <>
                    <section className="text-left">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4" style={{ color: mundoActivo.color }}>{t.ATLAS.ORIGIN_SYNTAX}</h4>
                      <p className="italic text-slate-600 dark:text-slate-300 text-base leading-relaxed border-l-4 pl-6" style={{ borderColor: mundoActivo.color }}>{selectedItem.descripcion}</p>
                    </section>

                    {selectedItem.categoria === 'Evento' && (selectedItem.descripcionInicio || selectedItem.descripcionFinal) && (
                      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-slate-50 dark:bg-slate-900 rounded-3xl p-6 border-l-4" style={{ borderColor: `${mundoActivo.color}88` }}>
                           <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 text-slate-400">Punto de Origen</h4>
                           <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{selectedItem.descripcionInicio || "Sin registro de inicio."}</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-900 rounded-3xl p-6 border-l-4" style={{ borderColor: mundoActivo.color }}>
                           <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 text-slate-400">Punto de Desenlace</h4>
                           <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{selectedItem.descripcionFinal || "En progreso / Sin registro final."}</p>
                        </div>
                      </section>
                    )}

                    <section className="text-left">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4" style={{ color: mundoActivo.color }}>{t.ATLAS.LORE_DOCUMENTED}</h4>
                      <div className="text-slate-800 dark:text-slate-200 text-base whitespace-pre-wrap leading-relaxed font-medium">{renderContent(selectedItem.contenido)}</div>
                    </section>
                  </>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <textarea placeholder="Descripción del Inicio..." value={editForm?.descripcionInicio} onChange={(e) => setEditForm({...editForm!, descripcionInicio: e.target.value})} className="w-full p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl h-24 outline-none border-2 border-transparent transition-all" style={{ borderColor: `${mundoActivo.color}22` }} />
                      <textarea placeholder="Descripción del Fin..." value={editForm?.descripcionFinal} onChange={(e) => setEditForm({...editForm!, descripcionFinal: e.target.value})} className="w-full p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl h-24 outline-none border-2 border-transparent transition-all" style={{ borderColor: `${mundoActivo.color}22` }} />
                    </div>
                    <textarea value={editForm?.descripcion} onChange={(e) => setEditForm({...editForm!, descripcion: e.target.value})} className="w-full p-5 bg-slate-50 dark:bg-slate-900 rounded-3xl h-24 outline-none border-2 border-transparent transition-all" style={{ borderColor: isEditing ? `${mundoActivo.color}33` : undefined }} />
                    <textarea value={editForm?.contenido} onChange={(e) => setEditForm({...editForm!, contenido: e.target.value})} className="w-full p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl min-h-[250px] outline-none border-2 border-transparent transition-all" style={{ borderColor: isEditing ? `${mundoActivo.color}33` : undefined }} />
                  </div>
                )}
             </div>

             <div className="p-6 sm:p-8 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800/50 shrink-0">
                {!isEditing ? (
                  <div className="flex gap-4">
                    <button onClick={handleExpand} disabled={isAnalyzing} className="flex-[3] flex items-center justify-center gap-3 text-slate-900 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] shadow-xl disabled:opacity-50 active-scale transition-all" style={{ backgroundColor: mundoActivo.color }}>
                      {isAnalyzing ? <RotateCcw className="animate-spin" /> : <Sparkles />} {t.ATLAS.EXPAND}
                    </button>
                    <button onClick={() => {setEditForm({...selectedItem}); setIsEditing(true);}} className="flex-1 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] border border-slate-200 dark:border-slate-700 transition-all active-scale">{t.COMMON.MODIFY}</button>
                  </div>
                ) : (
                  <div className="flex gap-4">
                    <button onClick={handleAnalyzeAndSave} disabled={isAnalyzing} className="flex-1 text-slate-900 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] flex items-center justify-center gap-3 shadow-2xl disabled:opacity-50 active-scale" style={{ backgroundColor: mundoActivo.color }}>
                      {isAnalyzing ? <RotateCcw className="animate-spin" /> : <Save />} {t.COMMON.SAVE}
                    </button>
                    <button onClick={() => setIsEditing(false)} className="px-10 py-4 font-black uppercase text-[11px] tracking-[0.2em] text-slate-400 active-scale">{t.COMMON.CANCEL}</button>
                  </div>
                )}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Atlas;
