
import React, { useState } from 'react';
import { Sparkles, X, RotateCcw, MoreVertical, BookOpen, Layers, Printer, Save, Clock, CheckCircle, Trash2 } from 'lucide-react';
import { Mundo, MensajeBitacora } from '../types';

interface BitacoraProps {
  mundoActivo: Mundo;
  messages: MensajeBitacora[];
  setMessages: (msgs: MensajeBitacora[]) => void;
  onAnalyze: (text: string, isCleanup?: boolean) => Promise<void>;
  t: any;
}

const Bitacora = ({ mundoActivo, messages, setMessages, onAnalyze, t }: BitacoraProps) => {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<MensajeBitacora | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState('');
  const [selection, setSelection] = useState<number[]>([]);
  const [menuOpenId, setMenuOpenId] = useState<number | null>(null);

  const handleSave = async () => {
    if (!text.trim()) return;
    setIsAnalyzing(true);
    const newMessage: MensajeBitacora = {
      id: Date.now(),
      worldId: mundoActivo.id,
      texto: text,
      timestamp: new Date().toISOString()
    };
    setMessages([newMessage, ...messages]);
    const textToAnalyze = text;
    setText('');
    await onAnalyze(textToAnalyze);
    setIsAnalyzing(false);
  };

  const handleUpdate = async () => {
    if (!selectedMessage || !editText.trim()) return;
    setIsAnalyzing(true);
    const updatedMessages = messages.map(m => m.id === selectedMessage.id ? { ...m, texto: editText } : m);
    setMessages(updatedMessages);
    await onAnalyze(editText);
    setSelectedMessage({ ...selectedMessage, texto: editText });
    setIsEditing(false);
    setIsAnalyzing(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm(t.BITACORA.DELETE_WARNING || "Warning: This will alter reality. Continue?")) return;
    const remaining = messages.filter(m => m.id !== id);
    setMessages(remaining);
    setMenuOpenId(null);
    setSelection(prev => prev.filter(x => x !== id));
    if (selectedMessage?.id === id) setSelectedMessage(null);
    await onAnalyze("SISTEMA: Erased from reality.", true);
  };

  const handleBulkDelete = () => {
    if (confirm(t.BITACORA.BULK_DELETE || "¿Borrar registros seleccionados?")) {
      const remaining = messages.filter(m => !selection.includes(m.id));
      setMessages(remaining);
      setSelection([]);
      onAnalyze("SISTEMA: Bulk erasure performed.", true);
    }
  };

  const handleBulkExport = () => {
    const selectedMsgs = messages.filter(m => selection.includes(m.id));
    exportToPDF(selectedMsgs);
    setSelection([]);
  };

  const exportToPDF = (items: MensajeBitacora[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const content = items.map(m => `
      <div class="pdf-entry">
        <div class="pdf-meta">${t.BITACORA.REGISTRY}: LOG-${m.id.toString().slice(-4)} | ${new Date(m.timestamp).toLocaleString()}</div>
        <div class="pdf-title">${t.BITACORA.REGISTRY} - ${mundoActivo.nombre}</div>
        <div style="font-size: 1.1rem; line-height: 1.6; white-space: pre-wrap;">${m.texto}</div>
      </div>
    `).join('<hr style="margin: 3rem 0; opacity: 0.1;"/>');

    printWindow.document.write(`
      <html>
        <head>
          <title>${mundoActivo.nombre} - ${t.NAV.BITACORA}</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 3rem; color: #111; }
            .pdf-meta { font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; color: #666; margin-bottom: 0.5rem; text-transform: uppercase; }
            .pdf-title { font-family: 'Playfair Display', serif; font-size: 1.8rem; margin-bottom: 1.5rem; border-bottom: 2px solid #000; padding-bottom: 0.5rem; }
            @media print { hr { page-break-after: always; visibility: hidden; } }
          </style>
        </head>
        <body>
          ${content}
          <script>setTimeout(() => { window.print(); window.close(); }, 500);</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const toggleSelect = (id: number) => {
    setSelection(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 max-w-4xl mx-auto pb-20 md:pb-12 relative">
      {/* Barra de Selección Masiva (Flotante) */}
      {selection.length > 0 && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-2rem)] max-w-lg bg-slate-900/90 dark:bg-slate-800/90 backdrop-blur-2xl px-6 py-4 rounded-full shadow-2xl border border-white/10 flex items-center justify-between gap-4 animate-in slide-in-from-top-12 duration-500">
           <div className="flex items-center gap-4">
              <button onClick={() => setSelection([])} className="p-2 bg-white/10 rounded-full text-white active-scale">
                <X size={16} />
              </button>
              <span className="text-white text-[11px] font-black uppercase tracking-widest">{selection.length} {t.BITACORA.REGISTRY ? 'Seleccionados' : 'Selected'}</span>
           </div>
           <div className="flex items-center gap-2">
              <button onClick={handleBulkExport} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all active-scale" title={t.COMMON.EXPORT_PDF}>
                <Printer size={18} />
              </button>
              <button onClick={handleBulkDelete} className="p-3 bg-rose-500/20 hover:bg-rose-500/40 text-rose-400 rounded-2xl transition-all active-scale" title={t.COMMON.DELETE}>
                <Trash2 size={18} />
              </button>
           </div>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-[2rem] md:rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden focus-within:ring-4 transition-all no-print" style={{ ringColor: `${mundoActivo.color}33` }}>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={t.BITACORA.PLACEHOLDER}
          className="w-full h-40 md:h-44 p-6 md:p-10 resize-none outline-none text-slate-700 dark:text-slate-200 bg-transparent text-base md:text-xl font-medium leading-relaxed"
        />
        <div className="px-6 md:px-10 py-5 bg-slate-50/50 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Layers size={14} className="text-slate-300" />
            <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">{text.length} {t.BITACORA.SYMBOLS}</span>
          </div>
          <button
            onClick={handleSave}
            disabled={!text.trim() || isAnalyzing}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 md:px-10 py-4 rounded-2xl font-black text-[11px] uppercase tracking-[0.15em] transition-all text-slate-900 shadow-xl active:scale-95 disabled:opacity-50"
            style={{ backgroundColor: mundoActivo.color }}
          >
            {isAnalyzing ? <RotateCcw className="animate-spin" size={16} /> : <Sparkles size={16} />}
            {t.COMMON.SYNC}
          </button>
        </div>
      </div>

      <div className="space-y-4 md:space-y-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center p-12 bg-white/50 dark:bg-slate-900/50 rounded-[2.5rem] md:rounded-[3rem] border border-dashed border-slate-200 dark:border-slate-800 opacity-60">
            <BookOpen size={48} className="text-slate-300 mb-6" />
            <h2 className="text-xl font-black text-slate-800 dark:text-white mb-2 uppercase tracking-tighter">{t.BITACORA.EMPTY}</h2>
            <p className="text-slate-400 font-medium text-xs uppercase tracking-widest max-w-xs leading-relaxed">{t.BITACORA.EMPTY_SUB}</p>
          </div>
        ) : (
          messages.map((m) => {
            const isSelected = selection.includes(m.id);
            return (
              <div 
                key={m.id} 
                onContextMenu={(e) => { e.preventDefault(); toggleSelect(m.id); }}
                onClick={() => selection.length > 0 ? toggleSelect(m.id) : setSelectedMessage(m)} 
                className={`group relative bg-white dark:bg-slate-900 rounded-[2rem] md:rounded-[2.5rem] border transition-all duration-500 ${isSelected ? 'shadow-2xl scale-[1.01]' : 'border-slate-100 dark:border-slate-800 hover:shadow-xl'}`}
                style={{ borderColor: isSelected ? mundoActivo.color : undefined, borderWidth: isSelected ? '2px' : '1px' }}
              >
                <div className="rounded-[2rem] md:rounded-[2.5rem] overflow-hidden">
                  <div className="px-5 md:px-8 py-4 bg-slate-50/50 dark:bg-slate-800/20 flex justify-between items-center border-b border-slate-50 dark:border-slate-800/50">
                    <div className="flex items-center gap-2 md:gap-3">
                      <span className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest bg-white dark:bg-slate-800 px-2 py-1 rounded-lg">{t.BITACORA.REGISTRY}-{m.id.toString().slice(-4)}</span>
                      <span className="text-[8px] md:text-[9px] text-slate-400 font-black uppercase tracking-widest">{new Date(m.timestamp).toLocaleTimeString()}</span>
                      {isSelected && <CheckCircle size={14} style={{ color: mundoActivo.color }} />}
                    </div>
                    <button 
                      onClick={(e) => { e.stopPropagation(); if (selection.length > 0) toggleSelect(m.id); else setMenuOpenId(menuOpenId === m.id ? null : m.id); }} 
                      className="p-2 text-slate-300 hover:text-blue-500 rounded-full transition-all" 
                      style={{ color: (menuOpenId === m.id || isSelected) ? mundoActivo.color : undefined }}
                    >
                      {isSelected ? <CheckCircle size={18} /> : <MoreVertical size={18} />}
                    </button>
                  </div>
                  <div className="p-6 md:p-10 cursor-pointer transition-all duration-700 active:bg-slate-50 dark:active:bg-slate-800/20 max-h-40 bg-gradient-to-b from-white to-slate-50/20 dark:from-slate-900 dark:to-slate-800/10 relative">
                    {isSelected && (
                      <div className="absolute inset-0 bg-slate-900/5 backdrop-blur-[1px] z-0" />
                    )}
                    <p className="text-slate-700 dark:text-slate-200 font-medium leading-relaxed italic text-sm line-clamp-2 opacity-70 relative z-10">{m.texto}</p>
                    <div className="mt-4 flex items-center gap-2 text-[9px] font-black uppercase tracking-[0.2em] opacity-60 relative z-10" style={{ color: mundoActivo.color }}>
                      <BookOpen size={12} /> {t.BITACORA.REVEAL}
                    </div>
                  </div>
                </div>
                {menuOpenId === m.id && (
                  <div className="absolute top-14 right-6 z-[110] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-2xl p-2 min-w-[180px] md:min-w-[200px] animate-in slide-in-from-top-4" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => { toggleSelect(m.id); setMenuOpenId(null); }} className="w-full flex items-center gap-4 px-5 py-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl text-[10px] font-black uppercase tracking-widest text-left">
                      <CheckCircle size={16} style={{ color: isSelected ? mundoActivo.color : '#94a3b8' }} /> {isSelected ? t.COMMON.CLEAN : 'Seleccionar Varios'}
                    </button>
                    <button onClick={() => { exportToPDF([m]); setMenuOpenId(null); }} className="w-full flex items-center gap-4 px-5 py-4 hover:bg-slate-50 rounded-2xl text-[10px] font-black uppercase tracking-widest text-left" style={{ color: mundoActivo.color }}>
                      <Printer size={16} /> {t.COMMON.EXPORT_PDF}
                    </button>
                    <div className="h-px bg-slate-100 dark:bg-slate-800 my-1 mx-2" />
                    <button onClick={() => handleDelete(m.id)} className="w-full flex items-center gap-4 px-5 py-4 hover:bg-rose-50 text-rose-500 rounded-2xl text-[10px] font-black uppercase tracking-widest text-left">
                      <Trash2 size={16} /> {t.COMMON.DELETE}
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {selectedMessage && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-2xl" onClick={() => !isEditing && setSelectedMessage(null)} />
          <div className="relative bg-white dark:bg-slate-950 w-full max-w-4xl h-full sm:h-auto max-h-full sm:max-h-[90vh] sm:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95">
             <div className="bg-slate-900 p-8 sm:p-12 pb-6 relative shrink-0">
               <div className="flex justify-between items-start mb-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 font-black text-[10px] uppercase tracking-[0.3em]" style={{ color: mundoActivo.color }}>
                      <Clock size={12} /> {new Date(selectedMessage.timestamp).toLocaleDateString()}
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tighter uppercase">{isEditing ? t.BITACORA.EDITING : `${t.BITACORA.REGISTRY}-${selectedMessage.id.toString().slice(-4)}`}</h2>
                  </div>
                  <button onClick={() => { setSelectedMessage(null); setIsEditing(false); }} className="p-3 bg-white/10 rounded-full text-white active-scale"><X size={20} /></button>
               </div>
               <div className="h-1 w-20 rounded-full" style={{ backgroundColor: mundoActivo.color }} />
             </div>
             <div className="p-6 sm:p-12 overflow-y-auto flex-1 space-y-8 custom-scrollbar">
                {!isEditing ? (
                  <>
                    <section>
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4" style={{ color: mundoActivo.color }}>{t.BITACORA.METADATA}</h4>
                      <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl">
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{t.BITACORA.CONTENT}: {selectedMessage.texto.length} {t.BITACORA.SYMBOLS}.</p>
                      </div>
                    </section>
                    <section>
                      <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4" style={{ color: mundoActivo.color }}>{t.BITACORA.CONTENT}</h4>
                      <div className="text-slate-800 dark:text-slate-200 text-base leading-relaxed font-medium italic border-l-4 pl-6" style={{ borderColor: mundoActivo.color }}>{selectedMessage.texto}</div>
                    </section>
                  </>
                ) : (
                  <textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="w-full p-6 bg-slate-50 dark:bg-slate-900 rounded-[2rem] min-h-[300px] outline-none border-2 border-transparent transition-all" style={{ borderColor: isEditing ? `${mundoActivo.color}33` : undefined }} />
                )}
             </div>
             <div className="p-6 sm:p-8 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800/50 shrink-0">
                {!isEditing ? (
                  <div className="flex gap-4">
                    <button onClick={() => onAnalyze(selectedMessage.texto)} disabled={isAnalyzing} className="flex-[3] flex items-center justify-center gap-3 text-slate-900 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] shadow-xl disabled:opacity-50 active-scale transition-all" style={{ backgroundColor: mundoActivo.color }}>
                      {isAnalyzing ? <RotateCcw className="animate-spin" /> : <Sparkles />} {t.COMMON.AI_DEEPEN}
                    </button>
                    <button onClick={() => { setEditText(selectedMessage.texto); setIsEditing(true); }} className="flex-1 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] border border-slate-200 dark:border-slate-700 transition-all active-scale">{t.COMMON.MODIFY}</button>
                  </div>
                ) : (
                  <div className="flex gap-4">
                    <button onClick={handleUpdate} disabled={isAnalyzing} className="flex-1 text-slate-900 py-4 rounded-2xl font-black uppercase text-[11px] tracking-[0.2em] flex items-center justify-center gap-3 shadow-2xl disabled:opacity-50 active-scale" style={{ backgroundColor: mundoActivo.color }}>
                      {isAnalyzing ? <RotateCcw className="animate-spin" /> : <Save />} {t.COMMON.SAVE}
                    </button>
                    <button onClick={() => setIsEditing(false)} className="px-10 py-4 font-black uppercase text-[11px] tracking-[0.2em] text-slate-400 active-scale">{t.COMMON.CANCEL}</button>
                  </div>
                )}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Bitacora;
