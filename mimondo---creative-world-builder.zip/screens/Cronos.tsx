
import React from 'react';
import { Sparkles, Calendar, ChevronRight, Clock, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { EventoCronos, EntradaAtlas } from '../types';

interface CronosProps {
  timeline: EventoCronos[];
  atlasItems: EntradaAtlas[]; // Añadido para verificar vínculos
  mundoColor: string;
  t: any;
}

const Cronos = ({ timeline, atlasItems, mundoColor, t }: CronosProps) => {
  const navigate = useNavigate();

  const handleNavigateToAtlas = (idAtlas: string) => {
    navigate('/atlas', { state: { openId: idAtlas } });
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-2 md:px-0">
      {timeline.length === 0 ? (
        <div className="text-center py-24 bg-white dark:bg-slate-950 rounded-[3.5rem] border-2 border-dashed border-slate-200 dark:border-slate-800 animate-in fade-in duration-1000">
          <Clock size={56} className="mx-auto mb-6 text-slate-200 dark:text-slate-800" />
          <p className="text-slate-400 font-black uppercase text-[11px] tracking-[0.4em]">{t.CRONOS.EMPTY}</p>
        </div>
      ) : (
        <div className="relative">
          <div className="absolute left-8 md:left-1/2 top-4 bottom-4 w-1 md:-translate-x-1/2 rounded-full" style={{ background: `linear-gradient(to bottom, ${mundoColor}88, #e2e8f0, transparent)` }} />
          <div className="space-y-16">
            {timeline.map((event, index) => {
              const isEven = index % 2 === 0;
              const linkedItem = atlasItems.find(item => item.id === event.idEntidadAtlas);
              const isDirectLink = linkedItem?.categoria === 'Evento';
              const hasLink = !!linkedItem;

              return (
                <div key={event.id} className={`relative flex flex-col md:flex-row items-center ${isEven ? 'md:flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-12 duration-700`} style={{ animationDelay: `${index * 100}ms` }}>
                  <div className="absolute left-8 md:left-1/2 -ml-3 md:-ml-3 w-6 h-6 rounded-full border-4 border-slate-50 dark:border-slate-950 shadow-lg z-10" style={{ backgroundColor: mundoColor }} />
                  <div className="w-full pl-20 md:pl-0 md:w-1/2">
                    <div 
                      className={`p-8 bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-sm border transition-all duration-500 group cursor-default relative ${isEven ? 'md:mr-12' : 'md:ml-12'} ${isDirectLink ? 'shadow-lg ring-2 ring-opacity-20 ring-offset-2' : 'border-slate-100 dark:border-slate-800/50'}`}
                      style={{ 
                        borderColor: isDirectLink ? mundoColor : undefined,
                        boxShadow: isDirectLink ? `0 20px 40px -15px ${mundoColor}33` : undefined
                      }}
                    >
                      <div className="flex items-center gap-3 mb-4 w-fit px-4 py-2 rounded-2xl" style={{ backgroundColor: `${mundoColor}22`, color: mundoColor }}>
                         <Calendar size={14} strokeWidth={3} />
                         <span className="text-[10px] font-black uppercase tracking-[0.2em]">{event.fecha}</span>
                      </div>
                      
                      <h3 className="text-xl font-black text-slate-900 dark:text-white mb-3 tracking-tighter uppercase leading-tight" style={{ color: mundoColor }}>{event.titulo}</h3>
                      <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed font-medium mb-6 line-clamp-3">{event.descripcionCorta}</p>
                      
                      <div className="flex items-center justify-between pt-6 border-t border-slate-50 dark:border-slate-800/50">
                         <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 dark:text-slate-500 bg-slate-50/50 dark:bg-slate-950/50 px-4 py-2 rounded-xl uppercase tracking-widest">
                           <Sparkles size={12} className="animate-pulse" style={{ color: mundoColor }} /> {t.CRONOS.AXIS}: {event.id.slice(-4)}
                         </div>
                         
                         {hasLink && (
                           <button 
                             onClick={() => handleNavigateToAtlas(event.idEntidadAtlas)}
                             className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all bg-slate-900 text-white hover:scale-105 active-scale shadow-md"
                             style={{ backgroundColor: isDirectLink ? mundoColor : undefined, color: isDirectLink ? '#1e293b' : undefined }}
                             title="Ver en Atlas"
                           >
                             <ExternalLink size={14} />
                             <span className="hidden sm:inline">Ver en Atlas</span>
                           </button>
                         )}
                      </div>

                      {/* Tooltip o Badge de Vinculación */}
                      {hasLink && (
                        <div className="absolute -top-3 -right-3 px-3 py-1 bg-white dark:bg-slate-800 rounded-full border border-slate-100 dark:border-slate-700 shadow-sm">
                           <p className="text-[8px] font-black uppercase tracking-tighter" style={{ color: mundoColor }}>
                             {isDirectLink ? 'Evento Maestro' : `Ref: ${linkedItem.nombre}`}
                           </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default Cronos;
