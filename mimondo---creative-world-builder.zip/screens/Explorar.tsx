
import React, { useState } from 'react';
import { Sparkles, Dices, Trash2, RotateCcw, Zap, Send, ShieldCheck, Ghost } from 'lucide-react';
import { Mundo, IdeaExplorada, EntradaAtlas } from '../types';
import { generateStoryIdea } from '../services/geminiService';

interface ExplorarProps {
  mundoActivo: Mundo;
  atlasItems: EntradaAtlas[];
  aiLanguage: string;
  onSaveIdea: (text: string) => void;
  t: any;
}

const GENRES = ['Fantasía Épica', 'Cyberpunk', 'Terror', 'Romance', 'Misterio', 'Ciencia Ficción', 'Realismo Mágico', 'Distopía', 'Aventura'];

const Explorar = ({ mundoActivo, atlasItems, aiLanguage, onSaveIdea, t }: ExplorarProps) => {
  const [genre, setGenre] = useState('Aleatorio');
  const [freedom, setFreedom] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [ideas, setIdeas] = useState<IdeaExplorada[]>([]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const selectedGenre = genre === 'Aleatorio' ? GENRES[Math.floor(Math.random() * GENRES.length)] : genre;
      const text = await generateStoryIdea(selectedGenre, freedom, `${mundoActivo.nombre}: ${mundoActivo.sintaxis}`, atlasItems, aiLanguage);
      // Add worldId to satisfy IdeaExplorada interface
      const newIdea: IdeaExplorada = {
        id: Date.now().toString(),
        worldId: mundoActivo.id,
        texto: text || "IA error.",
        genero: selectedGenre,
        timestamp: new Date().toISOString()
      };
      setIdeas([newIdea, ...ideas]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden border border-white/5">
          <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full blur-[80px] opacity-30" style={{ backgroundColor: mundoActivo.color }} />
          <h2 className="text-xl font-black mb-8 flex items-center gap-3 relative z-10" style={{ color: mundoActivo.color }}>
            <Zap fill="currentColor" size={20} /> {t.EXPLORAR.TITLE}
          </h2>
          <div className="space-y-8 relative z-10">
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-3">{t.EXPLORAR.TONE}</label>
              <select value={genre} onChange={(e) => setGenre(e.target.value)} className="w-full bg-white/10 border border-white/10 text-white p-4 rounded-2xl outline-none font-bold text-[12px]">
                <option value="Aleatorio" className="bg-slate-900">Aleatorio</option>
                {GENRES.map(g => <option key={g} value={g} className="bg-slate-900">{g}</option>)}
              </select>
            </div>
            <div className={`p-5 rounded-2xl border transition-all duration-500 ${freedom ? 'bg-amber-500/10 border-amber-500/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
               <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {freedom ? <Ghost size={16} className="text-amber-400" /> : <ShieldCheck size={16} className="text-emerald-400" />}
                    <span className="text-xs font-black uppercase tracking-tighter">{freedom ? t.EXPLORAR.EXPERIMENTAL : t.EXPLORAR.GUARDIAN}</span>
                  </div>
                  <button onClick={() => setFreedom(!freedom)} className={`relative inline-flex h-5 w-10 items-center rounded-full transition-all ${freedom ? 'bg-amber-500' : 'bg-emerald-500'}`}>
                    <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${freedom ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
               </div>
               <p className="text-[9px] text-slate-400 leading-tight font-medium">{freedom ? t.EXPLORAR.EXP_DESC : t.EXPLORAR.GUA_DESC}</p>
            </div>
            <button onClick={handleGenerate} disabled={isGenerating} className="w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 transition-all text-slate-900 shadow-xl" style={{ backgroundColor: isGenerating ? '#1e293b' : mundoActivo.color }}>
              {isGenerating ? <RotateCcw className="animate-spin" size={16} /> : <Sparkles size={16} />} {t.EXPLORAR.GENERATE}
            </button>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800">
          <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-4">{t.EXPLORAR.STATUS}</h4>
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full ${atlasItems.length >= 3 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400">{atlasItems.length} {t.EXPLORAR.RECORDS} {atlasItems.length < 3 && t.EXPLORAR.MIN_REQ}</span>
          </div>
        </div>
      </div>
      <div className="lg:col-span-8 space-y-5">
        {ideas.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full py-20 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-dashed border-slate-200 dark:border-slate-800 text-slate-300">
             <Dices size={48} className="opacity-10 mb-4" />
             <p className="font-black uppercase tracking-widest text-[9px]">{t.EXPLORAR.EMPTY}</p>
          </div>
        ) : (
          ideas.map((idea) => (
            <div key={idea.id} className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all animate-in slide-in-from-right-8 duration-500">
              <div className="flex justify-between items-center mb-5">
                <span className="text-[10px] font-black px-3 py-1 rounded-xl uppercase tracking-widest" style={{ backgroundColor: `${mundoActivo.color}22`, color: mundoActivo.color }}>{idea.genero}</span>
                <div className="flex items-center gap-2">
                  <button onClick={() => onSaveIdea(idea.texto)} className="p-2.5 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all" style={{ color: mundoActivo.color }} title="Sync"><Send size={18} /></button>
                  <button onClick={() => setIdeas(ideas.filter(i => i.id !== idea.id))} className="p-2.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={18} /></button>
                </div>
              </div>
              <p className="text-slate-800 dark:text-slate-200 leading-relaxed font-medium text-sm md:text-base italic">"{idea.texto}"</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Explorar;
