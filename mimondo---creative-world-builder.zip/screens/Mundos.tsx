
import React, { useState } from 'react';
import { X, Plus, Globe, Check, Edit2, Trash, Save, Palette, Sparkles, Book, Printer, AlertCircle } from 'lucide-react';
import { Mundo, EstadoMundo } from '../types';

interface MundosProps {
  mundos: Mundo[];
  allWorldsData: Record<string, EstadoMundo>;
  onClose: () => void;
  onSelect: (id: string) => void;
  onCreate: (mundo: Mundo) => void;
  onDelete: (id: string) => void;
  onUpdate: (mundo: Mundo) => void;
  currentMundoId: string;
  t: any;
}

const PASTEL_PALETTE = [
  '#7dd3fc', // Azul Cielo
  '#6ee7b7', // Verde Menta
  '#f9a8d4', // Rosa Suave
  '#c4b5fd', // Lavanda
  '#fdba74', // Melocotón
];

const Mundos = ({ mundos, allWorldsData, onClose, onSelect, onCreate, onDelete, onUpdate, currentMundoId, t }: MundosProps) => {
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [form, setForm] = useState<Mundo>({ id: '', nombre: '', genero: '', sintaxis: '', color: PASTEL_PALETTE[0] });

  const handleCreate = () => {
    if (!form.nombre) return;
    if (mundos.length >= 5) {
      alert(t.MUNDOS.LIMIT_REACHED);
      return;
    }
    const nuevo = { ...form, id: `mundo-${Date.now()}` };
    onCreate(nuevo);
    setIsCreating(false);
    setForm({ id: '', nombre: '', genero: '', sintaxis: '', color: PASTEL_PALETTE[0] });
  };

  const handleUpdate = () => {
    if (!form.nombre) return;
    onUpdate(form);
    setIsEditing(null);
  };

  const exportCompendium = (mundo: Mundo) => {
    const data = allWorldsData[mundo.id];
    if (!data) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const bitacoraContent = data.bitacora.map(m => `
      <div class="entry">
        <div class="meta">${t.BITACORA.REGISTRY} ${new Date(m.timestamp).toLocaleDateString()}</div>
        <div class="text italic">${m.texto}</div>
      </div>
    `).join('');

    printWindow.document.write(`
      <html>
        <head><title>${mundo.nombre} - ${t.MUNDOS.EXPORT_COMPENDIUM}</title></head>
        <body>
          <h1 style="text-align:center">${mundo.nombre}</h1>
          <h2>${t.NAV.BITACORA}</h2>
          ${bitacoraContent}
          <script>setTimeout(() => { window.print(); window.close(); }, 500);</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-xl animate-in fade-in" onClick={onClose} />
      <div className="relative bg-white dark:bg-slate-950 w-full max-w-2xl h-full sm:h-auto sm:max-h-[85vh] sm:rounded-[3.5rem] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95">
        <div className="px-8 py-8 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight uppercase">{t.MUNDOS.MANAGER}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{t.MUNDOS.CAPACITY}: {mundos.length}/5</span>
            </div>
          </div>
          <button onClick={onClose} className="p-3 text-slate-400"><X size={24} /></button>
        </div>

        <div className="p-6 md:p-8 overflow-y-auto flex-1 space-y-4 custom-scrollbar">
          {mundos.map((m) => {
            const isActive = m.id === currentMundoId;
            const data = allWorldsData[m.id];
            return (
              <div 
                key={m.id}
                className={`group relative flex flex-col gap-4 p-6 rounded-[2.5rem] border-2 transition-all duration-500 ${isActive ? 'bg-blue-50/10 dark:bg-blue-600/5' : 'border-slate-100 dark:border-slate-800'}`}
                style={{ borderColor: isActive ? m.color : undefined }}
              >
                <div className="flex items-center gap-5 cursor-pointer" onClick={() => onSelect(m.id)}>
                  <div className="w-16 h-16 rounded-3xl flex items-center justify-center text-slate-900 shadow-2xl" style={{ backgroundColor: m.color }}><Globe size={32} /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3">
                      <h3 className="font-black text-xl text-slate-900 dark:text-white tracking-tighter uppercase truncate">{m.nombre}</h3>
                      {isActive && <div className="bg-white p-1 rounded-full shadow-lg" style={{ color: m.color }}><Check size={10} strokeWidth={4} /></div>}
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{m.genero}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                   <button onClick={() => exportCompendium(m)} className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 dark:bg-slate-800 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest"><Printer size={14} /> {t.MUNDOS.EXPORT_COMPENDIUM}</button>
                   <div className="flex items-center gap-1">
                      <button onClick={() => { setForm(m); setIsEditing(m.id); }} className="p-3 text-slate-400"><Edit2 size={18} /></button>
                      <button onClick={() => { if(confirm(t.MUNDOS.DELETE_CONFIRM)) onDelete(m.id); }} className="p-3 text-slate-400"><Trash size={18} /></button>
                   </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-8 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
          <button 
            onClick={() => { setForm({ id: '', nombre: '', genero: '', sintaxis: '', color: PASTEL_PALETTE[0] }); setIsCreating(true); }}
            disabled={mundos.length >= 5}
            className={`w-full py-5 rounded-3xl font-black text-[11px] uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${mundos.length >= 5 ? 'bg-slate-200 dark:bg-slate-800 text-slate-400' : 'bg-blue-600 text-white'}`}
          >
            {mundos.length >= 5 ? <AlertCircle size={20} /> : <Plus size={20} />}
            {mundos.length >= 5 ? t.MUNDOS.LIMIT_REACHED : t.MUNDOS.CREATE_NEW}
          </button>
        </div>

        {(isCreating || isEditing) && (
          <div className="absolute inset-0 z-50 bg-white dark:bg-slate-950 p-8 flex flex-col animate-in slide-in-from-bottom-20">
            <div className="flex justify-between items-center mb-10">
               <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase">{isCreating ? t.MUNDOS.CREATE_NEW : t.MUNDOS.EDIT}</h3>
               <button onClick={() => { setIsCreating(false); setIsEditing(null); }}><X size={24} /></button>
            </div>
            <div className="flex-1 space-y-8 overflow-y-auto pb-10 custom-scrollbar">
               <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.MUNDOS.NAME}</label>
                  <input value={form.nombre} onChange={(e) => setForm({...form, nombre: e.target.value})} className="w-full p-5 bg-slate-50 dark:bg-slate-900 rounded-3xl text-xl font-black outline-none" />
               </div>
               <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.MUNDOS.GENRE}</label>
                  <input value={form.genero} onChange={(e) => setForm({...form, genero: e.target.value})} className="w-full p-5 bg-slate-50 dark:bg-slate-900 rounded-3xl font-bold outline-none" />
               </div>
               <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.MUNDOS.SYNTAX}</label>
                  <textarea value={form.sintaxis} onChange={(e) => setForm({...form, sintaxis: e.target.value})} className="w-full p-5 bg-slate-50 dark:bg-slate-900 rounded-3xl h-24 outline-none" />
               </div>
               <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest"><Palette size={14} /> {t.MUNDOS.COLOR}</label>
                  <div className="flex flex-wrap gap-4 p-4">
                     {PASTEL_PALETTE.map(c => (
                       <button key={c} onClick={() => setForm({...form, color: c})} className={`w-12 h-12 rounded-2xl transition-all ${form.color === c ? 'ring-4 ring-blue-500/30 scale-110' : 'opacity-40'}`} style={{ backgroundColor: c }} />
                     ))}
                  </div>
               </div>
            </div>
            <div className="pt-8 border-t border-slate-100 dark:border-slate-800">
               <button onClick={isCreating ? handleCreate : handleUpdate} className="w-full text-slate-900 py-5 rounded-3xl font-black text-[11px] uppercase tracking-[0.2em] shadow-2xl" style={{ backgroundColor: form.color }}>
                 <Save size={18} /> {t.MUNDOS.FINISH}
               </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Mundos;
