
import React, { useState, useEffect, useRef } from 'react';
import { Moon, Languages, ChevronRight, Database, Sun, HelpCircle, Cloud, RefreshCw, ShieldCheck, Zap, ExternalLink, DownloadCloud, FileOutput, FileInput, AlertTriangle, Save } from 'lucide-react';
import { authenticateGoogle, saveToDrive, loadFromDrive } from '../services/googleDriveService';
import { Idioma } from '../types';

interface SettingsProps {
  onNotify: (msg: string) => void;
  onShowOnboarding: () => void;
  idioma: Idioma;
  setIdioma: (lang: Idioma) => void;
  t: any;
}

const APIKeyInput = ({ slot, onNotify, t }: { slot: number, onNotify: (m: string) => void, t: any }) => {
  const keyName = `mimondo_key_${slot}`;
  const [val, setVal] = useState(localStorage.getItem(keyName) || '');
  const [isSaved, setIsSaved] = useState(!!val);

  const save = () => {
    localStorage.setItem(keyName, val);
    setIsSaved(!!val);
    onNotify(`${t.SETTINGS.ENERGY} ${slot} OK.`);
  };

  return (
    <div className="flex items-center gap-3 p-2 bg-slate-100/50 dark:bg-slate-800/50 rounded-3xl border-2 border-transparent focus-within:border-blue-500/20 transition-all">
      <div className={`p-4 rounded-2xl ${isSaved ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-400'}`}>
        <Zap size={18} fill={isSaved ? "currentColor" : "none"} />
      </div>
      <input 
        type="password" 
        value={val} 
        onChange={(e) => setVal(e.target.value)}
        placeholder={`API Key ${slot}...`}
        className="flex-1 bg-transparent outline-none text-xs font-mono font-bold tracking-widest text-slate-700 dark:text-slate-200"
      />
      <button onClick={save} className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${isSaved ? 'bg-white dark:bg-slate-700 text-slate-500 border border-slate-100 dark:border-slate-600' : 'bg-blue-600 text-white shadow-xl shadow-blue-600/20'}`}>
        {isSaved ? t.COMMON.MODIFY : t.COMMON.SAVE}
      </button>
    </div>
  );
};

const SettingItem = ({ icon: Icon, title, subtitle, action, onClick, danger = false, toggle = false, toggled = false }: any) => (
  <div onClick={onClick} className="flex items-center gap-5 p-5 rounded-[2rem] hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-all cursor-pointer group">
    <div className={`p-4 rounded-2xl transition-all duration-300 ${danger ? 'bg-rose-50 dark:bg-rose-900/20 text-rose-500' : 'bg-white dark:bg-slate-900 text-slate-500'}`}>
      <Icon size={22} />
    </div>
    <div className="flex-1">
      <h4 className={`font-black text-sm tracking-tight uppercase ${danger ? 'text-rose-600' : 'text-slate-800 dark:text-slate-200'}`}>{title}</h4>
      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 mt-1">{subtitle}</p>
    </div>
    {toggle ? (
      <div className={`w-12 h-7 rounded-full p-1 transition-all ${toggled ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-700'}`}>
        <div className={`w-5 h-5 bg-white rounded-full shadow-lg transition-transform ${toggled ? 'translate-x-5' : 'translate-x-0'}`} />
      </div>
    ) : action ? (
      <div className="text-[10px] font-black uppercase tracking-widest text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-4 py-2 rounded-xl">{action}</div>
    ) : (
      <ChevronRight size={20} className="text-slate-300 group-hover:text-blue-500 transform group-hover:translate-x-1" />
    )}
  </div>
);

const SettingsScreen = ({ onNotify, onShowOnboarding, idioma, setIdioma, t }: SettingsProps) => {
  const [darkMode, setDarkMode] = useState(() => document.documentElement.classList.contains('dark'));
  const [isSyncing, setIsSyncing] = useState(false);
  const [googleUser, setGoogleUser] = useState<string | null>(localStorage.getItem('mimondo_google_connected'));
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const handleSyncUp = async () => {
    setIsSyncing(true);
    try { await saveToDrive({ ...localStorage }); onNotify("Sync Complete"); }
    catch (e) { onNotify("Sync Error"); }
    finally { setIsSyncing(false); }
  };

  const handleRestore = async () => {
    if(!confirm("Restore?")) return;
    setIsSyncing(true);
    try {
      const data = await loadFromDrive();
      if (data) {
        Object.keys(data).forEach(key => {
          if (key.startsWith('mimondo_')) localStorage.setItem(key, data[key]);
        });
        onNotify("Restore Complete. Reloading...");
        setTimeout(() => window.location.reload(), 2000);
      }
    } catch (e) { onNotify("No backup found."); }
    finally { setIsSyncing(false); }
  };

  const handleExportBackup = () => {
    const backupData: Record<string, any> = {
      metadata: {
        app: "MiMondo",
        version: "2.1",
        timestamp: new Date().toISOString(),
        worldCount: JSON.parse(localStorage.getItem('mimondo_worlds_list_v2') || '[]').length
      },
      data: {}
    };

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('mimondo_')) {
        backupData.data[key] = localStorage.getItem(key);
      }
    }

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mimondo_full_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onNotify("Backup Exported.");
  };

  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!confirm(t.SETTINGS.IMPORT_WARNING)) {
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string;
        const backup = JSON.parse(content);

        if (!backup.metadata || !backup.data || backup.metadata.app !== "MiMondo") {
          throw new Error("Invalid backup file structure.");
        }

        const keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('mimondo_')) keysToRemove.push(key);
        }
        keysToRemove.forEach(k => localStorage.removeItem(k));

        Object.entries(backup.data).forEach(([key, value]) => {
          localStorage.setItem(key, value as string);
        });

        onNotify("Realidad Restaurada. Sincronizando...");
        
        if (localStorage.getItem('mimondo_google_connected')) {
          await saveToDrive({ ...localStorage });
        }

        setTimeout(() => window.location.reload(), 1500);
      } catch (err) {
        onNotify("Import Failed: " + (err as Error).message);
      }
    };
    reader.readAsText(file);
  };

  // Función para limpieza total y reinicio
  const handleCollapseReality = () => {
    if (window.confirm(t.MUNDOS.DELETE_CONFIRM)) {
      localStorage.clear();
      // Redirigir al origen para asegurar un estado limpio total
      window.location.href = window.location.origin + window.location.pathname;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-12 py-8 pb-48 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <section>
        <div className="flex items-center justify-between mb-6 px-4">
          <h3 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] flex items-center gap-3"><ShieldCheck size={14} /> {t.SETTINGS.ENERGY}</h3>
          <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] bg-blue-50 dark:bg-blue-950/40 px-5 py-2.5 rounded-2xl hover:brightness-110 active:scale-95 transition-all">
            {t.SETTINGS.GET_KEYS} <ExternalLink size={12} />
          </a>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-8 border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
          <p className="text-[10px] text-slate-400 font-bold px-2 uppercase tracking-widest">{t.SETTINGS.KEYS_DESC}</p>
          <div className="space-y-4">
            <APIKeyInput slot={1} onNotify={onNotify} t={t} />
            <APIKeyInput slot={2} onNotify={onNotify} t={t} />
            <APIKeyInput slot={3} onNotify={onNotify} t={t} />
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-6 px-4 flex items-center gap-3"><Cloud size={14} /> {t.SETTINGS.NEURAL_STORAGE}</h3>
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-4 border border-slate-100 dark:border-slate-800 shadow-xl space-y-2">
          {!googleUser ? (
            <SettingItem icon={Cloud} title={t.SETTINGS.SYNC_DRIVE} subtitle={t.SETTINGS.DRIVE_DESC} action={t.MUNDOS.MANAGER} onClick={async () => {
              try {
                await authenticateGoogle();
                setGoogleUser("Connected");
                localStorage.setItem('mimondo_google_connected', 'true');
                onNotify("Google Account Linked.");
              } catch(e) { onNotify("Link Error."); }
            }} />
          ) : (
            <>
              <SettingItem icon={RefreshCw} title={t.SETTINGS.UPLOAD} subtitle={t.SETTINGS.DRIVE_DESC} action={isSyncing ? "..." : t.SETTINGS.UPLOAD} onClick={handleSyncUp} />
              <SettingItem icon={DownloadCloud} title={t.SETTINGS.DOWNLOAD} subtitle={t.SETTINGS.DRIVE_DESC} action={isSyncing ? "..." : t.SETTINGS.DOWNLOAD} onClick={handleRestore} />
              <button onClick={() => { localStorage.removeItem('mimondo_google_connected'); setGoogleUser(null); }} className="w-full py-4 text-[9px] font-black text-rose-400 hover:text-rose-600 transition-colors uppercase tracking-[0.3em] mt-4">{t.SETTINGS.UNLINK}</button>
            </>
          )}
        </div>
      </section>

      <section>
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-6 px-4 flex items-center gap-3"><Save size={14} /> {t.SETTINGS.BACKUP_TITLE}</h3>
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-8 border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
           <div className="flex items-start gap-4 p-5 bg-amber-50 dark:bg-amber-900/10 rounded-3xl border border-amber-100 dark:border-amber-900/30">
              <AlertTriangle className="text-amber-500 shrink-0 mt-1" size={20} />
              <p className="text-[10px] font-bold text-amber-700 dark:text-amber-400 leading-relaxed uppercase tracking-tight">{t.SETTINGS.PRIVACY_WARN}</p>
           </div>
           
           <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={handleExportBackup}
                className="flex items-center justify-center gap-3 p-6 bg-slate-900 dark:bg-slate-800 text-white rounded-[2rem] hover:scale-[1.02] active-scale transition-all shadow-xl shadow-slate-900/10"
              >
                <FileOutput size={20} />
                <span className="text-[10px] font-black uppercase tracking-widest">{t.SETTINGS.EXPORT_BTN}</span>
              </button>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-3 p-6 bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 text-slate-900 dark:text-white rounded-[2rem] hover:bg-slate-50 dark:hover:bg-slate-800 active-scale transition-all shadow-sm"
              >
                <FileInput size={20} />
                <span className="text-[10px] font-black uppercase tracking-widest">{t.SETTINGS.IMPORT_BTN}</span>
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportBackup} 
                accept=".json" 
                className="hidden" 
              />
           </div>
           <p className="text-[9px] text-center text-slate-400 font-bold uppercase tracking-widest">{t.SETTINGS.BACKUP_DESC}</p>
        </div>
      </section>

      <section>
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-6 px-4">{t.SETTINGS.ORACLE_PREF}</h3>
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-4 border border-slate-100 dark:border-slate-800 shadow-xl space-y-2">
          <SettingItem icon={darkMode ? Moon : Sun} title={t.SETTINGS.THEME} subtitle={darkMode ? t.SETTINGS.DARK : t.SETTINGS.LIGHT} toggle toggled={darkMode} onClick={() => setDarkMode(!darkMode)} />
          <SettingItem icon={Languages} title={t.SETTINGS.LANGUAGE} subtitle={idioma === 'es' ? 'Español' : 'English'} onClick={() => setIdioma(idioma === 'es' ? 'en' : 'es')} />
          <SettingItem icon={HelpCircle} title={t.SETTINGS.GUIDE} subtitle={t.SETTINGS.GUIDE} onClick={onShowOnboarding} />
        </div>
      </section>

      <section>
        <h3 className="text-[10px] font-black text-rose-500/50 uppercase tracking-[0.4em] mb-6 px-4">{t.SETTINGS.CRITICAL}</h3>
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-4 border border-slate-100 dark:border-slate-800 shadow-xl">
          <SettingItem 
            icon={Database} 
            title={t.SETTINGS.COLLAPSE} 
            subtitle={t.SETTINGS.COLLAPSE_SUB} 
            danger 
            onClick={handleCollapseReality} 
          />
        </div>
      </section>
    </div>
  );
};

export default SettingsScreen;
