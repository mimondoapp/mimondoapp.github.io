
import { GoogleGenAI, Type } from "@google/genai";

/**
 * Obtiene la siguiente API Key disponible rotando entre las 3 posibles ingresadas por el usuario.
 */
const getNextApiKey = (): string => {
  const keys = [
    localStorage.getItem('mimondo_key_1'),
    localStorage.getItem('mimondo_key_2'),
    localStorage.getItem('mimondo_key_3')
  ].filter(k => k && k.trim() !== "");

  if (keys.length === 0) {
    throw new Error("ORÁCULO SIN ENERGÍA: No se han configurado API Keys en el Núcleo.");
  }

  let currentIndex = parseInt(localStorage.getItem('mimondo_key_index') || '0');
  const selectedKey = keys[currentIndex % keys.length];
  localStorage.setItem('mimondo_key_index', ((currentIndex + 1) % keys.length).toString());
  
  return selectedKey;
};

/**
 * Procesa el texto para extraer lore, entidades y cronología con énfasis en consolidación de eventos Inicio/Fin.
 */
export const processLoreDeeply = async (text: string, currentContext: string, language: string = 'Español') => {
  const apiKey = getNextApiKey();
  const ai = new GoogleGenAI({ apiKey });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Eres un Supervisor de Coherencia de Datos y Maestro Cronista. 
    TU TAREA:
    Analiza el "Nuevo Texto" e intégralo en el lore de manera consolidada, evitando datos huérfanos.
    
    REGLAS DE ORO DE CONSOLIDACIÓN Y COHERENCIA:
    1. PRIORIDAD ATLAS: Toda entidad o evento DEBE ser una tarjeta en el Atlas.
    2. EVENTOS UNIFICADOS (INICIO/FIN): No fragmentes un suceso. Crea una sola tarjeta de Evento. Si el texto describe el comienzo, rellena "descripcionInicio". Si describe el desenlace, rellena "descripcionFinal". Si ya existe en el contexto, sugiere la actualización de estos campos.
    3. NO DATOS HUÉRFANOS: Todo Astro o Evento cronológico DEBE estar anclado a una tarjeta de Atlas.
    4. ACTUALIZACIÓN (PATCH): Si el texto aporta nueva info sobre algo que YA EXISTE en el contexto, enfócate en completar los campos faltantes (especialmente el "Fin" de un evento).

    IDIOMA DE RESPUESTA: ${language}.

    CONTEXTO ACTUAL:
    ${currentContext}

    NUEVO TEXTO A ANALIZAR:
    "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          atlas: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                nombre: { type: Type.STRING },
                categoria: { type: Type.STRING, description: "Uno de: Personaje, Lugar, Objeto, Evento, Concepto" },
                descripcion: { type: Type.STRING },
                contenido: { type: Type.STRING },
                descripcionInicio: { type: Type.STRING, description: "Relato del comienzo del evento (si aplica)" },
                descripcionFinal: { type: Type.STRING, description: "Relato del desenlace/fin del evento (si aplica)" }
              },
              required: ["nombre", "categoria", "descripcion", "contenido"]
            }
          },
          cronos: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                fecha: { type: Type.STRING },
                descripcion: { type: Type.STRING }
              },
              required: ["titulo", "fecha", "descripcion"]
            }
          },
          astros: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                entidadA: { type: Type.STRING },
                entidadB: { type: Type.STRING }
              },
              required: ["entidadA", "entidadB"]
            }
          }
        }
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

/**
 * Expande la información de un elemento del atlas.
 */
export const expandAtlasItem = async (item: any, worldContext: string, language: string = 'Español') => {
  const apiKey = getNextApiKey();
  const ai = new GoogleGenAI({ apiKey });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Como gran cronista, expande el lore de esta entidad.
    Idioma: ${language}.
    Mundo: "${worldContext}"
    Entidad: ${JSON.stringify(item)}
    Crea una narrativa profunda. Si es un evento con inicio/fin, detalla la transición.`,
  });
  return response.text;
};

/**
 * Genera ideas de historias basadas en el contexto del mundo.
 */
export const generateStoryIdea = async (genre: string, creativeFreedom: boolean, worldContext: string, atlasItems: any[], language: string = 'Español') => {
  const apiKey = getNextApiKey();
  const ai = new GoogleGenAI({ apiKey });
  
  const instruction = creativeFreedom ? "Oráculo experimental." : "Guardián del canon.";
    
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Mundo: "${worldContext}". 
    Entidades: ${atlasItems.map(i => i.nombre).join(', ')}.
    Género: ${genre}.
    Genera un Spark narrativo coherente.`,
    config: { systemInstruction: `${instruction} Idioma: ${language}.` }
  });
  return response.text;
};
