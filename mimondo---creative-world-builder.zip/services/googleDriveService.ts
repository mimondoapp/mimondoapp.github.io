
/**
 * Servicio para la integración con Google Drive (Client-Side Only)
 * Utiliza el espacio 'appDataFolder' para almacenamiento invisible y seguro.
 */

const CLIENT_ID = '1085503835012-5n27ae2d0uvk656j6db9j31b283tkg83.apps.googleusercontent.com'; 
const SCOPES = 'https://www.googleapis.com/auth/drive.appdata';
const FILE_NAME = 'mimondo_app_vault.json';

let accessToken: string | null = null;

/**
 * Autenticación mediante Google Identity Services
 */
export const authenticateGoogle = (): Promise<string> => {
  return new Promise((resolve, reject) => {
    try {
      const client = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        callback: (response: any) => {
          if (response.error) {
            console.error("Auth Error:", response.error);
            reject(response);
          }
          accessToken = response.access_token;
          resolve(response.access_token);
        },
      });
      client.requestAccessToken();
    } catch (err) {
      reject(err);
    }
  });
};

/**
 * Guarda la base de datos en la carpeta oculta de la App en Drive
 */
export const saveToDrive = async (data: any) => {
  if (!accessToken) await authenticateGoogle();

  // Buscar archivo en appDataFolder
  const searchResponse = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=name='${FILE_NAME}'&spaces=appDataFolder&fields=files(id)`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  const searchResult = await searchResponse.json();
  const fileId = searchResult.files?.[0]?.id;

  const metadata = {
    name: FILE_NAME,
    parents: ['appDataFolder'],
    mimeType: 'application/json',
  };

  const formData = new FormData();
  formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  formData.append('file', new Blob([JSON.stringify(data)], { type: 'application/json' }));

  const url = fileId 
    ? `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=multipart`
    : `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart`;

  const method = fileId ? 'PATCH' : 'POST';

  const response = await fetch(url, {
    method,
    headers: { Authorization: `Bearer ${accessToken}` },
    body: formData,
  });

  if (!response.ok) throw new Error("Error al sincronizar con la nube");
  return true;
};

/**
 * Recupera la base de datos desde la carpeta oculta
 */
export const loadFromDrive = async () => {
  if (!accessToken) await authenticateGoogle();

  const searchResponse = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=name='${FILE_NAME}'&spaces=appDataFolder&fields=files(id)`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  const searchResult = await searchResponse.json();
  const fileId = searchResult.files?.[0]?.id;

  if (!fileId) throw new Error("No se encontró respaldo en tu AppData de Drive.");

  const fileResponse = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  
  if (!fileResponse.ok) throw new Error("Error al descargar los datos");
  return await fileResponse.json();
};
