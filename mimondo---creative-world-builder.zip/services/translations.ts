
import { Idioma } from '../types';

export const translations = {
  es: {
    NAV: {
      BITACORA: "Bitácora",
      ATLAS: "Atlas",
      CRONOS: "Cronos",
      ASTROS: "Astros",
      EXPLORAR: "Explorar"
    },
    COMMON: {
      SAVE: "Guardar",
      CANCEL: "Cancelar",
      DELETE: "Eliminar",
      MODIFY: "Modificar",
      EXPORT_PDF: "Exportar PDF",
      SYNC: "Sincronizar Realidad",
      AI_EXPAND: "IA Expandir",
      AI_DEEPEN: "IA Profundizar",
      SEARCH: "Encontrar...",
      CLEAN: "Limpiar",
      NEW: "Nuevo",
      BACK: "Atrás",
      NEXT: "Siguiente",
      START: "Comenzar"
    },
    MUNDOS: {
      MANAGER: "Gestor de Realidades",
      SUBTITLE: "Multiverso de Creación",
      CAPACITY: "Capacidad",
      CREATE_NEW: "Engendrar Nuevo Mundo",
      LIMIT_REACHED: "Límite de Multiverso Alcanzado",
      EDIT: "Editar Realidad",
      DELETE_CONFIRM: "¿Destruir este mundo? Todo el lore se perderá.",
      EXPORT_COMPENDIUM: "Exportar Compendio",
      NAME: "Nombre del Mundo",
      GENRE: "Género / Temática",
      SYNTAX: "Sintaxis (Resumen)",
      COLOR: "Color de Esencia",
      FINISH: "Finalizar Engendro"
    },
    BITACORA: {
      PLACEHOLDER: "Narra un nuevo fragmento de tu historia...",
      SYMBOLS: "símbolos",
      EMPTY: "Papel en Blanco",
      EMPTY_SUB: "El universo aguarda tu primera palabra.",
      REGISTRY: "Registro",
      REVEAL: "Revelar Crónica",
      METADATA: "Metadatos del Registro",
      CONTENT: "Contenido de la Crónica",
      EDITING: "Editando Registro"
    },
    ATLAS: {
      EMPTY_SUB: "Nueva Ficha",
      EXPAND: "Expandir Lore",
      LORE_DOCUMENTED: "Crónicas Documentadas",
      ORIGIN_SYNTAX: "Sintaxis del Origen",
      BULK_DELETE: "¿Borrar fichas seleccionadas?",
      CATEGORY: "Categoría",
      MERGE_DUPLICATES: "Fusionar Duplicados",
      MERGE_SUCCESS: "Realidad consolidada: Duplicados fusionados."
    },
    CRONOS: {
      EMPTY: "Sin registros históricos documentados",
      AXIS: "Eje"
    },
    EXPLORAR: {
      TITLE: "LAB DE IDEAS",
      TONE: "Tono Narrativo",
      EXPERIMENTAL: "Modo Experimental",
      GUARDIAN: "Modo Guardián",
      EXP_DESC: "La IA puede ignorar el lore y traer elementos inexistentes.",
      GUA_DESC: "Fidelidad absoluta. La IA solo usará elementos de tu Atlas.",
      GENERATE: "Generar Spark",
      STATUS: "Estado del Atlas",
      RECORDS: "tarjetas registradas",
      MIN_REQ: "(mínimo 3 para mejor precisión)",
      EMPTY: "Sin chispas generadas aún"
    },
    SETTINGS: {
      ENERGY: "Energía Primaria",
      GET_KEYS: "Obtener Llaves",
      KEYS_DESC: "Configura hasta 3 llaves para rotación automática.",
      NEURAL_STORAGE: "Almacenamiento Neural",
      SYNC_DRIVE: "Sincronizar con Drive",
      DRIVE_DESC: "Respaldo automático de Lore y Credenciales",
      UPLOAD: "Subir a la Nube",
      DOWNLOAD: "Restaurar desde Nube",
      UNLINK: "Desvincular Google Account",
      ORACLE_PREF: "Preferencias del Oráculo",
      THEME: "Interfaz Visual",
      DARK: "Estética de Medianoche",
      LIGHT: "Estética de Mediodía",
      LANGUAGE: "Idioma del Sistema",
      GUIDE: "Iniciar Guía",
      CRITICAL: "Nivel Crítico",
      COLLAPSE: "Colapsar Realidad",
      COLLAPSE_SUB: "Borrar permanentemente todo el Lore",
      BACKUP_TITLE: "Respaldo del Multiverso",
      BACKUP_DESC: "Exporta/Importa todos tus mundos y llaves en un archivo .json.",
      EXPORT_BTN: "Exportar Respaldo",
      IMPORT_BTN: "Importar Respaldo",
      IMPORT_WARNING: "ATENCIÓN: Se sobrescribirán todos los datos actuales. ¿Continuar?",
      PRIVACY_WARN: "El archivo contiene tus API Keys. Guárdalo en un lugar seguro."
    }
  },
  en: {
    NAV: {
      BITACORA: "Chronicle",
      ATLAS: "Atlas",
      CRONOS: "Timeline",
      ASTROS: "Astros",
      EXPLORAR: "Explore"
    },
    COMMON: {
      SAVE: "Save",
      CANCEL: "Cancel",
      DELETE: "Delete",
      MODIFY: "Modify",
      EXPORT_PDF: "Export PDF",
      SYNC: "Sync Reality",
      AI_EXPAND: "AI Expand",
      AI_DEEPEN: "AI Deepen",
      SEARCH: "Search...",
      CLEAN: "Clear",
      NEW: "New",
      BACK: "Back",
      NEXT: "Next",
      START: "Start"
    },
    MUNDOS: {
      MANAGER: "Reality Manager",
      SUBTITLE: "Creative Multiverse",
      CAPACITY: "Capacity",
      CREATE_NEW: "Spawn New World",
      LIMIT_REACHED: "Multiverse Limit Reached",
      EDIT: "Edit Reality",
      DELETE_CONFIRM: "Destroy this world? All lore will be lost.",
      EXPORT_COMPENDIUM: "Export Compendium",
      NAME: "World Name",
      GENRE: "Genre / Theme",
      SYNTAX: "Syntax (Summary)",
      COLOR: "Essence Color",
      FINISH: "Finish Spawning"
    },
    BITACORA: {
      PLACEHOLDER: "Narrate a new fragment of your story...",
      SYMBOLS: "symbols",
      EMPTY: "Blank Paper",
      EMPTY_SUB: "The universe awaits your first word.",
      REGISTRY: "Registry",
      REVEAL: "Reveal Chronicle",
      METADATA: "Registry Metadata",
      CONTENT: "Chronicle Content",
      EDITING: "Editing Registry"
    },
    ATLAS: {
      EMPTY_SUB: "New Entry",
      EXPAND: "Expand Lore",
      LORE_DOCUMENTED: "Documented Chronicles",
      ORIGIN_SYNTAX: "Origin Syntax",
      BULK_DELETE: "Delete selected entries?",
      CATEGORY: "Category",
      MERGE_DUPLICATES: "Merge Duplicates",
      MERGE_SUCCESS: "Reality consolidated: Duplicates merged."
    },
    CRONOS: {
      EMPTY: "No documented historical records",
      AXIS: "Axis"
    },
    EXPLORAR: {
      TITLE: "IDEAS LAB",
      TONE: "Narrative Tone",
      EXPERIMENTAL: "Experimental Mode",
      GUARDIAN: "Guardian Mode",
      EXP_DESC: "AI can ignore lore and bring non-existent elements.",
      GUA_DESC: "Absolute fidelity. AI will only use Atlas elements.",
      GENERATE: "Generate Spark",
      STATUS: "Atlas Status",
      RECORDS: "registered cards",
      MIN_REQ: "(minimum 3 for better accuracy)",
      EMPTY: "No sparks generated yet"
    },
    SETTINGS: {
      ENERGY: "Primary Energy",
      GET_KEYS: "Get Keys",
      KEYS_DESC: "Configure up to 3 keys for automatic rotation.",
      NEURAL_STORAGE: "Neural Storage",
      SYNC_DRIVE: "Sync with Drive",
      DRIVE_DESC: "Automatic Lore and Credentials Backup",
      UPLOAD: "Upload to Cloud",
      DOWNLOAD: "Restore from Cloud",
      UNLINK: "Unlink Google Account",
      ORACLE_PREF: "Oracle Preferences",
      THEME: "Visual Interface",
      DARK: "Midnight Aesthetic",
      LIGHT: "Noonday Aesthetic",
      LANGUAGE: "System Language",
      GUIDE: "Start Guide",
      CRITICAL: "Critical Level",
      COLLAPSE: "Collapse Reality",
      COLLAPSE_SUB: "Permanently delete all Lore",
      BACKUP_TITLE: "Multiverse Backup",
      BACKUP_DESC: "Export/Import all your worlds and keys in a single .json file.",
      EXPORT_BTN: "Export Backup",
      IMPORT_BTN: "Import Backup",
      IMPORT_WARNING: "WARNING: This will overwrite all current data. Continue?",
      PRIVACY_WARN: "This file contains your API Keys. Keep it in a safe place."
    }
  }
};
