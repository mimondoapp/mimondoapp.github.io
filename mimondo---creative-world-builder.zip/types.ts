
export type Idioma = 'es' | 'en';

export interface Mundo {
  id: string;
  nombre: string;
  genero: string;
  sintaxis: string;
  color: string;
}

export interface EntradaAtlas {
  id: string;
  worldId: string; // Vínculo obligatorio al mundo
  nombre: string;
  categoria: 'Personaje' | 'Lugar' | 'Objeto' | 'Evento' | 'Concepto';
  descripcion: string;
  contenido: string;
  etiquetas: string[];
  imagenUrl?: string;
  descripcionInicio?: string;
  descripcionFinal?: string;
}

export interface EventoCronos {
  id: string;
  worldId: string; // Vínculo obligatorio al mundo
  titulo: string;
  fecha: string;
  descripcionCorta: string;
  idEntidadAtlas: string; // ID de la Tarjeta Atlas (Entidad Madre)
}

export interface AstroNodo {
  id: string;
  worldId: string; // Vínculo obligatorio al mundo
  nombre: string;
  categoria?: 'Personaje' | 'Lugar' | 'Objeto' | 'Evento' | 'Concepto';
  x: number;
  y: number;
  color: string;
  conexiones: string[]; // IDs de otros nodos del mismo mundo
}

export interface MensajeBitacora {
  id: number;
  worldId: string; // Vínculo obligatorio al mundo
  texto: string;
  timestamp: string;
}

export interface IdeaExplorada {
  id: string;
  worldId: string;
  texto: string;
  genero: string;
  timestamp: string;
}

export interface EstadoMundo {
  bitacora: MensajeBitacora[];
  atlas: EntradaAtlas[];
  cronos: EventoCronos[];
  astros: AstroNodo[];
}
